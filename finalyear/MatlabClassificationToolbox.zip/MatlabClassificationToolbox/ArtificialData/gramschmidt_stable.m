function A = gramschmidt_stable(d)
%Graham Schmidt Procedure
%Given the dimensianality of the vector space
%Generates a new vector space with all axes orthogonal to each other
%The new vector space is defined by A

%Written by Christiaan M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

%Random feature axis values
for itr=1:d
    v = (rand(1,d)-ones(1,d).*0.5).*2;%generate numbers between [-1,1]
    V{itr} = v/norm(v);%normalise
end

%Build up a new orthogonal vector space from the original vector v
%Make sure all the columns are orthogonal and that each column 
%represents a unit vector
U{1} = V{1};%the first axis 
u = V{2} - proj(U{1}, V{2}); 
U{2} = u/norm(u);%the second axis  
for i=3:d
    u = V{i} - proj(U{1}, V{i}); 
    Uk{1} = u/norm(u);  
        for itr=2:i-1
            rec = Uk{itr-1};
            tmp = rec - proj(U{itr},rec);
            Uk{itr} = tmp/norm(tmp);
            %norm(Uk)
        end
    u = Uk{itr};%the last recursion
    U{i} = u/norm(u);%normalise to unit vector  
end

%Copy the new vector space into a matrix A
for i=1:d
   A(:,i)=U{i};
end

%A*A'%must give the indentity matrix I
covariance = A*A

%If A*A = covariance matrix then the true variances of the
%variables are equal to the eigen values
%The eigenvectors can be used to make the data
%uncorrelated
[U EV] = eig(covariance)
