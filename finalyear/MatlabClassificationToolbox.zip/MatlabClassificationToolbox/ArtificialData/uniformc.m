%This script generates data with that is uniformly distributed on a circle

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

close all
clear

N = 1000;%number of samples
d = 2;%dimensionality of multivariate data

%Calculate a new N to compensate for the samples
%that lies within the square but not in the circle
N1 = round(N*(4/pi));
radius = 1;

%Generate class 1 data
%Generate 1 dimensional uniformly distributed data
wd = 2;
x1 = rand(d,N1).*wd;%width of dist = 2
cntr = [0; 1];%center of distribution

figure(1)
hist(x1(1,:)')

%Generate multivariate data by sampling from a 
%prescribed density function
%Y = Ax + B
%Y - multivariate data
%A - AA' = covariance
%B - mean of multivariate data
A1 = [1 0; 0 1];%dxd
B1t = cntr - [wd/2; wd/2];%[-1; 0];%gives a uniform dist with mean 
B1 = repmat(B1t,1,N1);%repeat the mean to get dxN matrix 
y1 = A1*x1 + B1;%multivariate data

cntr2 = 1;
for cntr=1:N1
    tmp = y1(1,cntr)^2 +(y1(2,cntr)-1)^2;
    if tmp <= radius^2 
        if cntr2 <= N
            y1f(1, cntr2) = y1(1, cntr);
            y1f(2, cntr2) = y1(2, cntr);
            cntr2 = cntr2+1;            
        end
    end
end

data = y1f';%the final data set
figure(2)
hist3(y1f',[15 15])