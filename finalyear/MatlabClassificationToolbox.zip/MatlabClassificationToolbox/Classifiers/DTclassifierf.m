%DT Classifier
%Implementation of a Decision Tree Classifier

%Written by Christiaan M. van der Walt
%CSIR,Meraka Institute
%South-Africa
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%clear
%clc
%close all
%dsname = 'iris.txt';%'iris.txt';%'artificial2.txt';%'iris.txt';
function err = DTclassifierf(dsname, measure)

%fprintf('%s\n',dsname);
data =load(dsname);%load the data set

%measure = 2;%1 - entropy measure, 2 - mutual information measure

data = shuffle(data);

d = size(data,2)-1;%the dimensionality of the data
N = size(data,1);%the number of samples in the data set

%Determine the number of classes
if min(data(:,d+1)) == 0
    data(:,d+1)=data(:,d+1)+1;
    C = max(data(:,d+1));
else
    C = max(data(:,d+1));    
end

DTtraintest %train and test on all the data

%Perform 10-fold cross-validation
for cvn=1:10
    cvalid
    getcvfold
    attribs = 1:d;
    discl  = 10;%number of discrete levels when discretizing the data
    default = mvote(data_tr, C);%use majority vote as default class label
    %Train the DT   
    N = size(data_tr,1);
    %data_tr = shuffle(data_tr);
    tree = [];
    tree = DTlearning(data_tr, attribs, default, C, discl, N, measure);

    %Testing
    %examplesd = [];
    %Problem!!!
    %examplesd = discretize(data_te, discl)
    
    labels = [];
    labels = data_te(:,d+1);
    
    %Classify the test fold
    %cvn
    errs(cvn) = DTtest(data_te(:,1:d), labels, tree);
    fprintf('Err(fold %g) = %g\n',cvn,errs(cvn));
end%for cvn
err = sum(errs)/10;
%fprintf('Err = %g\n',cverr);

