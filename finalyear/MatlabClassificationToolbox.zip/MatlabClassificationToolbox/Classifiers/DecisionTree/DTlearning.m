%DTLearning
%A recursive function that generates a decision tree from traning data
function tree = DTlearning(examples, attribs, default, C, discl, N, measure)
%examples - consists of d+1 dimensional vectors stacked on each other,
%the d+1'th value is the class label for the observation

%if no more examples are left to train from for this subtree
if isempty(examples)
    for vitr=1:discl
        tree.values{vitr,2}=default; %return the default value    
    end
    %fprintf('Default %g\n',default);
    return
%if all examples have the same classification 
elseif length(find(examples(:,end)==examples(1,end))) == size(examples,1)
    for vitr=1:discl
        tree.values{vitr,2}=examples(1,end); %return the class label    
    end    
    %fprintf('Same %g\n',examples(1,end));
    return 
%if attribs is empty (all the attribtes have been considered)
%return the majority class label
elseif isempty(attribs)
    %%majority = mvote(examples,C);
    for vitr=1:discl
        %tree.values{vitr,2}=majority; %return the majority class label    
        tree.values{vitr,2}=default; %return the majority class label    
    end    
    %%fprintf('Empty %g\n',majority);
    %fprintf('Empty %g\n',default);
    return 
else
    %Determine best attribute and returns discrete data
    [best values examplesd] = bestattr(attribs, examples, C, discl, N, measure);%determine the best attribute
    %best
    %values
    tree  = maketree(best, attribs, examples, values);%make a subtree with the best attribute as root
    V = length(values);%the number of discrete values attribute best can take on
        
    for vitr=1:V
        %Get examples where attribute best has the value values(vitr)
        exidx = [];%clear vector
        examplesi = [];%clear matrix
        exidx = find(examplesd(:,best)==values(vitr));
        examplesi = examples(exidx,:);
        %Calculate the majority vote
        majority = mvote(examplesi,C);
        %Create a new subtree
        %attribs
        bidx = find(attribs == best);
        attribs(bidx) = [];%delete the best attribute after use
        %discl
        subtree = DTlearning(examplesi, attribs, majority, C, discl, N, measure);
        %Add a branch to tree with label values(vitr) and subtree subtree
        tree.values{vitr,2}=subtree;
    end%for vitr    
end%if