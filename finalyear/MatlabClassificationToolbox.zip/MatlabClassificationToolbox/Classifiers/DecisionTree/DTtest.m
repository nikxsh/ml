function err = DTtest(examplesd, labels, tree)
%examplesd - discrete data without class label
N = size(examplesd,1);
for itr=1:N
    x = examplesd(itr,:);   
    aname = tree.name;
    attr = tree.var;
    cl(itr) = DTtestbranch(tree, x, attr);
end
%cl
diff = cl' - labels;
correct = length(find(diff == 0));
err = 1 - correct/N;
