function cl = DTtestbranch(tree, x, attr)
%Returns the class label of an observation x
%x
%tree
%attr

xv = x(attr);%get the attr value of obseration x
tmp = [];

for itr=1:size(tree.values,1)
    tmp = [tmp tree.values{itr,1}];
end

%tmp 
%xv

%find(tmp == xv);
%idx = find(tmp == xv);

tmp2 = tmp - xv;
[mv idx] = min(abs(tmp2)); 
%idx
%~isempty(tmp2)

%if (size(tree.values{idx,2}.values,1)==1) & (size(tree.values{idx,2}.values,2)==1)
%if isinteger({tree.values{idx,2}})%if end of branch has been reached
%if (~isempty(tmp2)) & size(tree.values{idx,2}.values,1)==1
%(size(tree.values{idx,2},1))
    %(size(tree.values{idx,2},2))
if isempty(tmp)
    %cl = tree.values{idx,2};%class label
    cl = tree.values{1,2};%class label
    return
else%pursue tree
    %attr
    %attr
    tattr = attr;
    try        
        tattr = tree.values{idx,2}.var;        
        attr = tattr;
    catch        
        %attr = tattr;%stays the same
    end
    %attr
    cl = DTtestbranch(tree.values{idx,2}, x, attr);%call recursively
end%if

