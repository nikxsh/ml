%Training
examples = data;
attribs = 1:d;
discl  = 10;%number of discrete levels when discretizing the data
default = mvote(examples, C);%use majority vote as default class label

%Call the recursive learning algorithm
%train = [examples(1:40,:); examples(51:90,:); examples(101:140,:)];
tree = DTlearning(examples, attribs, default, C, discl, N, measure);

%Testing
%examplesd = discretize(examples, discl);

%%labels = [examples(41:50,d+1);examples(91:100,d+1); examples(141:150,d+1)];
labels = examples(:,d+1);

%Classify the test data
%test = [examplesd(41:50,:); examplesd(91:100,:); examplesd(141:150,:)];

err = DTtest(examples, labels, tree);
fprintf('Training Error = %g\n', err);
