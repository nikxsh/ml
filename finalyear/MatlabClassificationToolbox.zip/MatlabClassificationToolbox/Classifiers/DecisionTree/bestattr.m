function [best bvalues discdata] = bestattr(attribs,datain,C,discl,N, measure)

%size(datain)
%datain

%Selects the best attribute from given examples
%Uses information criteria to select best attribute


%Coverts any continious dataset to a discrete dataset
%each variable has 'discl' different discrete values
%Calculates prior prob of each discrete value
%Calculates entropy of each possible value
%Finally calculates the entropy of the entire dataset (avg of variable
%entropy's)

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%nosteps - no observations
%discl - discrete levels

%Discretize data
%discdata - the discretized data
%probval - the probablities of each discrete step of all the variables
%indexval - all posible values of the discrete data

%nosteps = size(datain,1)/(discl);
nosteps = N/discl;
mindatain = min(datain);
maxdatain = max(datain);
ranges = maxdatain - mindatain;
%make 10 dicrete values for each continous variable
%step size
steps = ranges/nosteps;
d = size(datain,2)-1;
labels = datain(:,d+1);

%make all values discrete, 10 discrete values per cell
for i=1:size(datain,1)    
    for j=1:d
        for count=1:nosteps
            diffs(count) = datain(i,j) - mindatain(j) - (count-1)*(steps(j));
        end
        
        %nosteps
        %diffs
        
        diffs = abs(diffs);
        [minv, winner] = min(diffs);
        newval = mindatain(j) + (winner-1)*steps(j);
        if(i == size(datain,1))
            newval = mindatain(j) + (winner-1)*steps(j);
        end
        discrdatain(i,j) = newval;
    end
end
%make a matrix that contains all possible values for each variable
for i=1:nosteps   
    for j=1:d
        indexval(i,j) = mindatain(j) + (i-1)*(steps(j)); 
    end
end

%--------------For Feature Selection-----------

%calculate the prior prob of each possible value
%the prob corresponds to the values in indexval
for i=1:nosteps    
    for j=1:d
        probval(i,j) = length(find(discrdatain(:,j) == indexval(i,j)))/size(datain, 1); 
    end
end
attrentropy = entropy(probval);
%calculate the entropy of the entire dataset
dsentropy = sum(attrentropy)/length(attrentropy);
%copy the probability matrix for use in cross_entropy.m
p = probval;

if measure == 1
%---------------Remainder--------------
%Calculate the prior prob of each possible value
%the prob corresponds to the values in indexval
%(Priors of Remainder)
for i=1:nosteps    
    for j=1:d
        idx = [];
        %find observations belonging to bin with value indexval
        idx = find(discrdatain(:,j) == indexval(i,j));
        %probability of a bin
        probval(i,j) = length(idx)/size(datain, 1);         
        for citr=1:C
            %determine what proportion of samples in the bin belongs to class citr
            if length(idx)>0
                labprobval(i,j,citr) = length(find(labels(idx)==citr))/length(idx);
            else
                labprobval(i,j,citr) = 0;
            end%if else
        end
    end%for
end%for

%Calculate Remainder for each attribute
remainder = zeros(1,d);
for j=1:d%attributes
    for i=1:nosteps%discrete levels
        %copy the probabilities
        for citr=1:C
            tmp(citr) = labprobval(i,j,citr);
        end
        remainder(1,j) = remainder(1,j)+probval(i,j)*entropy(tmp');
    end
end
%remainder
%----------------Gain----------------------
%Calculate class priors
for citr=1:C
    clprobval(citr) = length(find(labels == citr))/length(labels);
end

%Calculate the entropy of the class priors
clentropy = entropy(clprobval');

%Calculate Gain for each attribute
for j=1:d
    if length(find(attribs == j))==1
        gain(j) = clentropy - remainder(j);
    else%may not select this attribute
        gain(j)=0;
    end
end

%------------------------------------------
%Select the attribute with the maximum gain from attribs
[maxgain best] = max(gain);
end%if measure == 1

%------------------------
if measure == 2
data = datain;

discl = 10;%number of discrete levels
verb = 0;

%Basic Measures
obsn = size(data, 1); %number of rows
attrn = d;%determine the number of attributes (the last column is the class)
no_classes = C;
datain = data(:,1:attrn);
dataout = data(:,attrn+1);

%Perform Information Measures
%Calculates the entropy of the dataset (all the attributes)
%attr_entr;
%Calculates the entropy of the class
class_entr;
%Calculates the joint entropy of the class and attribute
joint_entr;

%Calculates all the information measures, using the 
%mutual information between the class variable
%and the dataset variables
mutual;
[dmi dmidx] = sort(mutualinf,'descend');
best = dmidx(1);
end%if measure == 2
%---------------------------------------

bvalues = indexval(:,best);
discdata = [discrdatain datain(:,end)];%discrete data with class labels

%attrentropy = entropy(probval);
%fprintf(fid,'The entropy values, H(X), of the attributes:\n');
%for itr=1:attrn
%    fprintf(fid,'%g     %g\n',itr, attrentropy(itr));
%end
%fprintf(fid,'\n');

%calculate the entropy of the entire dataset
%dsentropy = sum(attrentropy)/length(attrentropy);
%fprintf(fid,'The dataset entropy, sum(H(X))/p:\n');
%fprintf(fid,'%g\n',dsentropy);
%fprintf(fid,'\n');

%copy the probability matrix for use in cross_entropy.m
%p = probval;
