function  discrdatain = discretize(datain, discl)
%Coverts any continious dataset to a discrete dataset
%each variable has 'discl' different discrete values
%Calculates prior prob of each discrete value
%Calculates entropy of each possible value
%Finally calculates the entropy of the entire dataset (avg of variable
%entropy's)

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%nosteps - no observations
%discl - discrete levels

%Discretize data
%discdata - the discretized data
%probval - the probablities of each discrete step of all the variables
%indexval - all posible values of the discrete data

%nosteps = size(datain,1)/(discl);
N = size(datain,1);
d = size(datain,2)-1;
nosteps = N/discl;
mindatain = min(datain);
maxdatain = max(datain);
ranges = maxdatain - mindatain;
%make 10 dicrete values for each continous variable
%step size
steps = ranges/nosteps;
d = size(datain,2)-1;
labels = datain(:,d+1);

%make all values discrete, 10 discrete values per cell
for i=1:size(datain,1)    
    for j=1:d
        for count=1:nosteps
            diffs(count) = datain(i,j) - mindatain(j) - (count-1)*(steps(j));
        end
        
        %nosteps
        %diffs
        
        diffs = abs(diffs);
        [minv, winner] = min(diffs);
        newval = mindatain(j) + (winner-1)*steps(j);
        if(i == size(datain,1))
            newval = mindatain(j) + (winner-1)*steps(j);
        end
        discrdatain(i,j) = newval;
    end
end
%make a matrix that contains all possible values for each variable
for i=1:nosteps   
    for j=1:d
        indexval(i,j) = mindatain(j) + (i-1)*(steps(j)); 
    end
end

