function tree = maketree(best, attribs, examples, vals)
%tree - a subtree with the best attribute as root
%values - all possible values of the root(best) attribute

tree.name = sprintf('Attr%g',best);
tree.var = best;

V = length(vals);

%{1,1} - the value of the variable
%{1,2} - a subtree that must be attached
for vitr=1:V
    tree.values{vitr,1}=vals(vitr);        
end

