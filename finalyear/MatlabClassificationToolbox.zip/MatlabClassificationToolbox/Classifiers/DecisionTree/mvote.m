function majority = mvote(examples, C)
%Returns the class label with the majority vote for the examples given
%examples
labels = examples(:,end);
freq = zeros(1,C);
for citr=1:C
    freq(1,citr) = length(find(labels==citr));
end%for
%freq

[maxf majority] = max(freq);

%majority 
%maxf