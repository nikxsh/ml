%Implementation of the Expectation Maximization Algorithm

%Written by Christiaan M. van der Walt
%CSIR,Meraka Institute
%South-Africa
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recogniti

function [mweights mmeans mcov llh] = EM(M, mweightsi, mmeans, mcov, x, ITR, C);
%M - number of mixtures 
%mmeans - the initial mean values of all the mixtures
%mcov - the initial covariance values of the mixtures
%the training data
%data - the data of class C without class labels
%ITR - the maximum number of iterations for the EM
%C - the class number (which class conditional pdf to estimate)

N = size(x,1);
d = size(x,2);%data has no class labels
tolerance = 1.e-6;%1e-6measure of convergence in likelihood that must be reached
itr=0;
stop = 0;

meanm = mmeans;
covm = mcov;
mweights = mweightsi;

warning off all;


while (itr<=ITR)&(stop==0)
    %save prevois good values
    %backup values (in case of divide by zero)
    bmeanm = meanm;
    bcovm = covm;
    bmweights = mweights;
    
    itr = itr + 1;
    flag=0;
    %E-step (calculate p(i,j))
    for i=1:M %mixtures
        for j=1:N %samples
            %p(i,j)=p(x(j)|C=i)*p(C=i)
            %x(j,1:d) = data(j,1:d);
            
            %mvgauss(x(j,:),meanm{C,i},covm{C,i})*mweights{C,i}
            [mvgp stp]= mvgauss_stp(x(j,:),meanm{C,i},covm{C,i});
            if stp==0
                p(i,j) =mweights{C,i}*mvgp;
            end
            
            if stp==1
                flag=1;
                stop=1;
            end
        end%for j  
        
        %pri(i) = sum(p(i,:))
    end%for i

    %Problem! pri(i) gets smaller for each iteration
    %this 
    
    %normalize mixture probabilities for each sample
    %NB! The matrix p only has one row!
    for j=1:N
        alpha(j) = 1/(sum(p(:,j)));
        p(:,j) = p(:,j)*alpha(j);
    end
    %size(p)
    
    stop = 0;
    for i=1:M
        %????????? Add /N ????????
        pri(i) = sum(p(i,:))/N;%recalculate pri with normalized p(i,j) values
        %if pri(i) == 0%if pri is zero, stop the EM algorithm
        %    itr = ITR;
            
            %NB!!!!!!!!!!!Test this
            %stop = 1;
        %end
    end
       
    %pri
    if stop == 0
    %M-step
    %Update the mixture means
    for i=1:M
        tmean=zeros(1,d);
        for j=1:N
            tmean = tmean + (p(i,j)*x(j,:))/pri(i);%Remove!!!! /pri(i);
        end%for j
        
        try
        %    meanm{C,i} = tmean/(N*pri(i));%Add!!!! (N*pri(i))        
        catch%if pri(i)==0, then don't update the mean
        
        end
    end%for i
    
    %Update the mixture covariances
    for i=1:M
        tcov=zeros(d,d);
        tmpmean = meanm{C,i};
        for j=1:N
            %??????? -tmpean ???
            dif = x(j,:)-tmpmean;
            tcov = tcov + (dif'*dif).*p(i,j)/pri(i);            
            %tcov = tcov + (dif'*dif).*p(i,j);            
        end%for j
        
        %try
        %    tcov = tcov/(N*pri(i));%??????????
        %catch
        %    
        %end
        
        %test if cov becomes to small (variance flooring)
        for ritr=1:d
            tmp=[];
            tmp = mcov{C,i};
            %tmp
            if(tcov(ritr,ritr)<0.0001*tmp(ritr,ritr))|(tcov(ritr,ritr)==NaN)
                tcov(ritr,ritr)=0.0001*tmp(ritr,ritr);                    
                %tcov(ritr,ritr)
                %0.01*tmp(ritr,ritr)
            end%if
        end        
        covm{C,i} = tcov;    
    end%for i
    
    %covm{C,i} = mcov{C,i};%don't update cov, use initial ML cov
    
    %Update mixture weights
    %pri
    %mweights
    for i=1:M
        mweights{C,i} = pri(i);
    end
    
    end%if stop
    
    %Calculate the likelihood
    llh(itr) = 0;
    for nitr=1:N
        tmp=0;
        for mitr=1:M
            tmp = tmp + pri(mitr)*p(mitr,nitr);
        end%for mitr
        llh(itr) = llh(itr)+log(tmp);
    end%for nitr
    
    %Calculate stopping criterion
    thr = tolerance*llh;%threshold for convergence
    if itr>1
        if llh(itr) < llh(itr-1)%if likelihood decreases (diverges)
            stop = 1;
        elseif abs(llh(itr)-llh(itr-1))<thr%sufficient convergence is reached
            stop = 1;
        end%if-elseif
    end%if
    
    %use previous good values
    if flag == 1
        meanm = bmeanm;
        covm = bcovm;
        mweights = bmweights;
        stop =1;
    end

end%while