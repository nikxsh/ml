function means = kmeans_init(data, dsname, K, ITR, verbose)
%Implementation of the K-means clustering algorithm
%Used to initialize the EM algorithm

%dsname = 'iris.txt';
%mfolder = 'C:\Documents and Settings\CvdWalt\Desktop\myToolbox\Data\Measures';
%data =load(dsname);%load the data set

d = size(data,2)-1;%the dimensionality of the data
N = size(data,1);%the number of samples in the data set
%Determine the number of classes
if min(data(:,d+1)) == 0
    data(:,d+1)=data(:,d+1)+1;
    C = max(data(:,d+1));
else
    C = max(data(:,d+1));    
end 
%K = C;%the number of mixtures per class
%ITR = 100;%the maximum number of iterations

datat = data(:,1:d);
%Draw random samples as initial mean values for the clusters
ds = [];%drawn samples
for iitr=1:K
    sno = ceil(rand()*(N-iitr+1));%select a random observation
    means{iitr} = datat(sno,:);
    datat(sno,:)=[];%delete the sampled observation
end%fir

datat = data(:,1:d);
itr=0;
stop = 0;

while((itr<ITR) & (stop == 0)) 
    itr = itr+1;
    %E-step (Determine cluster numbers of observations)
    for nitr=1:N
        for kitr=1:K
            mean = means{kitr};
            x = datat(nitr,:);
            ed = edist(x,mean);
            distances(nitr,kitr) = ed;
        end%for kitr
            %assign observation to cluster with nearest mean
            [mv clval(nitr)] = min(distances(nitr,:));
     end%for nitr
    
    %M-step (Estimate new mean values)
    for kitr = 1:K
        idx{kitr}=find(clval==kitr);
        clustdat{kitr} = [datat(idx{kitr},:) clval(idx{kitr})'];%the K'th clusters data
        classdat{kitr} = data(idx{kitr},:);
        clustdat{kitr};
        
        if size(clustdat{kitr},1)>0
            %calculate the sample mean
            means{kitr} = ml_mean(clustdat{kitr});%the K'th clusters sample mean        
        else%if there is no data in the cluster
            means{kitr} = ml_mean(data);
        end
               
    end%for kitr
    
    %Calculate the distortion measure (stopping criterion)
    J(itr) = 0;
    for nitr=1:N
        J(itr) = J(itr) + distances(nitr,clval(nitr));
    end%for nitr
    %Test for convergence (stopping criterion)
    if (itr>1)
        if ((J(itr)-J(itr-1))== 0) 
            stop = 1;
        end%if    
    end%if
end%while

if verbose == 1
%Summary of data clustering
for kitr=1:K
    cldat = classdat{kitr};
    fprintf('Cluster %g (%g samples)\n',kitr,size(cldat,1));
    for citr=1:C        
        clc = length(find(cldat(:,end) == citr));
        fprintf('Class %g = %g\n',citr,clc);
    end
    cldat = [];
end

%Select two most significant features
minf = feature_selection(dsname,'',0);
[dmi dmidx] = sort(minf,'descend');
vars2D = dmidx(1:2);

%Plot the data
clrs = ['r' 'b' 'g' 'k' 'y' 'm'];
S = 10;%size 
clustd = clustdat{kitr};
classd = classdat{kitr}; 
        
%Clustered data
figure;
for citr=1:C
    cldat = clustdat{citr};
    scatter(cldat(:,vars2D(1)),cldat(:,vars2D(2)),S,clrs(citr),'filled')
    hold on;   
    cldat = [];
end
title('Clustered Data');
xlabel(sprintf('Feature %g',vars2D(1)));
ylabel(sprintf('Feature %g',vars2D(2)));

%Class data
figure;
for citr=1:C
    cidx{citr} = find(data(:,end)==citr); 
    cldat = data(cidx{citr},:);
    scatter(cldat(:,vars2D(1)),cldat(:,vars2D(2)),S,clrs(citr))
    hold on;   
    cldat = [];
end             
title('Class Data');
xlabel(sprintf('Feature %g',vars2D(1)));
ylabel(sprintf('Feature %g',vars2D(2)));
end%if verbose
