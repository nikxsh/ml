%K-Means Clustering

%Implementation of the K-means clustering algorithm
%Clusters data based on Euclidean distances 
%Clusters all the data in a data set

clear
clc
close all;

dsname = 'iris.txt';
mfolder = 'C:\Documents and Settings\CvdWalt\Desktop\myToolbox\Data\Measures';
data =load(dsname);%load the data set
d = size(data,2)-1;%the dimensionality of the data
N = size(data,1);%the number of samples in the data set
%Determine the number of classes
if min(data(:,d+1)) == 0
    data(:,d+1)=data(:,d+1)+1;
    C = max(data(:,d+1));
else
    C = max(data(:,d+1));    
end 
K = C;%the number of mixtures per class
ITR = 20;

datat = data(:,1:d);
%Draw random samples as initial mean values for the clusters
ds = [];%drawn samples
for iitr=1:K
    sno = ceil(rand()*(N-iitr+1));%select a random observation
    means{iitr} = datat(sno,:);
    datat(sno,:)=[];%delete the sampled observation
end%fir

datat = data(:,1:d);
for itr=1:ITR
    %E-step (Determine cluster numbers of observations)
    for nitr=1:N
        for kitr=1:K
            mean = means{kitr};
            x = datat(nitr,:);
            ed = edist(x,mean);
            distances(nitr,kitr) = ed;
        end%for kitr
            %assign observation to cluster with nearest mean
            [mv clval(nitr)] = min(distances(nitr,:));
     end%for nitr
    
    %M-step (Estimate new mean values)
    for kitr = 1:K
        idx{kitr}=find(clval==kitr);
        clustdat{kitr} = [datat(idx{kitr},:) clval(idx{kitr})'];%the K'th clusters data
        classdat{kitr} = data(idx{kitr},:);
        means{kitr} = ml_mean(clustdat{kitr});%the K'th clusters sample mean        
    end%for kitr
end%for itr

%Summary of data clustering
for kitr=1:K
    cldat = classdat{kitr};
    fprintf('Cluster %g (%g samples)\n',kitr,size(cldat,1));
    for citr=1:C        
        clc = length(find(cldat(:,end) == citr));
        fprintf('Class %g = %g\n',citr,clc);
    end
    cldat = [];
end

%Select two most significant features
minf = feature_selection(dsname,mfolder,0);
[dmi dmidx] = sort(minf,'descend');
vars2D = dmidx(1:2);

%Plot the data
clrs = ['r' 'b' 'g' 'k' 'y' 'm'];
S = 10;%size 
clustd = clustdat{kitr};
classd = classdat{kitr}; 
        
%Clustered data
figure;
for citr=1:C
    cldat = clustdat{citr};
    scatter(cldat(:,vars2D(1)),cldat(:,vars2D(2)),S,clrs(citr),'filled')
    hold on;   
    cldat = [];
end
title('Clustered Data');
xlabel(sprintf('Feature %g',vars2D(1)));
ylabel(sprintf('Feature %g',vars2D(2)));

%Class data
figure;
for citr=1:C
    cidx{citr} = find(data(:,end)==citr); 
    cldat = data(cidx{citr},:);
    scatter(cldat(:,vars2D(1)),cldat(:,vars2D(2)),S,clrs(citr))
    hold on;   
    cldat = [];
end             
title('Class Data');
xlabel(sprintf('Feature %g',vars2D(1)));
ylabel(sprintf('Feature %g',vars2D(2)));
