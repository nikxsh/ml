%Calculates the likelihood that an observation belongs to a specific 
%class (the class conditional probability density function consists of
%a summation of gaussians)

%Written by Christiaan M. van der Walt
%CSIR,Meraka Institute
%South-Africa
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recogniti

function lld = mixprob(M, mweights, mmeans, mcov, x, C)
%See Webb p.41
lld = 0;
for i=1:M %mixtures
    lld = lld + mvgauss(x,mmeans{C,i},mcov{C,i})*mweights{C,i};
end%for i