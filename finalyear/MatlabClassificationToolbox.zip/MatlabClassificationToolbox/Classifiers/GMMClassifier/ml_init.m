%Choose the mean values around the ML mean
if mitr > M/2
    mmeans{itr,mitr} = mean + (mean/M)*(mitr/2);%initial mean
else
    mmeans{itr,mitr} = mean - (mean/M)*(mitr/2);%initial mean
end