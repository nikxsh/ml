function [mvgp stop] = mvgauss_stp(x,mean,cov)
%Calculates the probability of an observation x with a
%multivariate normal distribution

%Written by Christiaan M. van der Walt
%CSIR,Meraka Institute
%South-Africa
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

try
    d = length(mean);
    t1 = det(cov)^0.5;
    coef = (1/((2*pi)^(d/2))*t1);
    dif = x-mean;
    dift = dif';
    pdist = exp(-0.5*dif*inv(cov)*dift);
    mvgp = coef*pdist;
    stop = 0;
catch
    mvgp = 0;
    %stop =1;
end

%cov