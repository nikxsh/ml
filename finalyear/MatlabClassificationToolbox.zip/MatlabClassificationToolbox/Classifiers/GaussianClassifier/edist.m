function dist = edist(x,y)
%Determines the Euclidean distance between two vectors, x and y.

%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

dif = x-y;%difference
difsq = dif.*dif;%difference squared
sdifsq = sum(difsq);%sum of squared difference
dist = sqrt(sdifsq);