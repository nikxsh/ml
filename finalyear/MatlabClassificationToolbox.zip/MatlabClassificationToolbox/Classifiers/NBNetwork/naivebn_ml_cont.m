%model ionosphere network using a naive Bayesian network
function [err errs] = naivebn_ml_cont(dsname)
%clear all

%load data:
%do_10fold
%load the data
%data = load('splice.txt');

data = load(dsname);
data = shuffle(data);
[N col] = size(data);
d = col-1;
%DL = 4;%discrete levels for each variable

if min(data(:,end))==0
    data(:,end)=data(:,end)+1;
    C = max(data(:,end));
else
    C = max(data(:,end));
end

%Perform 10-fold cross-validation
for cvn=1:10
    cvalid
    getcvfold      

    %clear previous BN and probability tables
    bnet = [];
    bnet.CPD = [];
    bnet2 = [];
    
    %creat graphical structure:
    %continuous node sizes are scalar
    
    node_sizes = ones(1,d+1);%continuous nodes (variables)
    node_sizes(d+1) = C;%discrete node (class label)
    
    dag = zeros(d+1,d+1);
    discrete_nodes = [d+1];
    dag(d+1,[1:d]) = 1;
    %draw_graph(dag);

    %Create the BN shell
    bnet = mk_bnet(dag, node_sizes, 'discrete', discrete_nodes);
    %Initialise probability tables
%     seed = 0;
%     rand('state', seed);
    
    for i = 1:d%the continuous variables
         %tabular - discrete (histogram)
         %gaussian - continuous
         bnet.CPD{i} = gaussian_CPD(bnet,i);
    end
    
    bnet.CPD{d+1} = tabular_CPD(bnet,d+1,'CPT', 'rnd', 'adjustable', 1, 'prior_type', 'none');
    
    %folds{cc}.train(:,61) = folds{cc}.train(:,61)+1;
    
    ncases = size(data_tr,1);
    cases = cell(d+1,ncases);
    cases = num2cell(data_tr);
    
    bnet2 = learn_params(bnet,cases');
    
    engine = jtree_inf_engine(bnet2);
    %and enter evidence
    evidence = cell(1,d+1); %empty cell array = no evidence
    
    %set error count to zero for current fold
    error = 0;
    %testing set:
    data_test = data_te;%folds{cc}.test;
    test_cases = size(data_test);
    
    for j = 1:test_cases(1)
        for i = 1:d
            evidence{i} = data_test(j,i);
        end

        [engine, ll] = enter_evidence(engine, evidence);
        marg = marginal_nodes(engine,d+1);
        %marg.T
        %c_hat = find(marg.T >= max(marg.T))-1;
        c_hat = find(marg.T >= max(marg.T));
        if c_hat ~= data_test(j,d+1)
            error = error+1;
        end
        
    end
    error = error/length(data_test);
    errs(cvn) = error;
    fprintf('Err (fold %g)= %g\n',cvn, errs(cvn));
end%for cvn
err = sum(errs)/10;
fprintf('Err = %g\n',err);




