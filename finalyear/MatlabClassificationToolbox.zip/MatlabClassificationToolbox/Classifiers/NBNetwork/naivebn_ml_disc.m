%model splice network using a naive Bayesian network
function [err errs] = naivebn_ml_disc(dsname)
%clear all

%ERROR = [];

%load data:
%do_10fold

%load the data
%data = load('splice.txt');

data = load(dsname);
data = shuffle(data);
[N col] = size(data);
d = col-1;
%DL = 4;%discrete levels for each variable

if min(data(:,end))==0
    data(:,end)=data(:,end)+1;
    C = max(data(:,end));
else
    C = max(data(:,end));
end

%Determine the discrete levels of each variable
%and make sure they all start from 1 to DL(ditr)
for ditr=1:d
    minv = min(data(:,ditr));     
    if minv == 0%then make minv == 1
        data(:,ditr) = data(:,ditr)+1;
    end
    maxv = max(data(:,ditr));
    %Thus all minimum values of discrete variables are 1
    DL(ditr)=maxv;
end

%Perform 10-fold cross-validation
for cvn=1:10
    cvalid
    getcvfold
      
    %clear previous BN and probability tables
    bnet = [];
    bnet.CPD = [];
    
    %create graphical structure:
    node_sizes = zeros(1,d+1);
    node_sizes(d+1) = C;
    node_sizes(1:d) = DL;%discrete levels
    dag = zeros(d+1,d+1);
    dag(d+1,[1:d]) = 1;
    %draw_graph(dag);

    %Create the BN shell
    bnet = mk_bnet(dag,node_sizes);
    %Initialise probability tables
%     seed = 0;
%     rand('state', seed);
    for i = 1:d+1
        %tabular - discrete (histogram)
        %gaussian - continuous
        bnet.CPD{i} = tabular_CPD(bnet, i, 'CPT', 'rnd', 'adjustable', 1, 'prior_type', 'none');
    end

    %train parameters with current fold:
    data_train = data_tr;
    %bnet = learn_params(bnet, data_train'+1);
    bnet = learn_params(bnet, data_train');
    
    %Choose inference engine: junction tree
    engine = jtree_inf_engine(bnet);

    %and enter evidence
    evidence = cell(1,d+1); %empty cell array = no evidence
    
    %set error count to zero for current fold
    error = 0;
    %testing set:
    data_test = data_te;
    
    for j = 1:length(data_test)
       
        %enter evidence for 60 features:
        for i = 1:d
            %evidence{i} = data_test(j,i) + 1;%if min disc level value for this variable = 0
            evidence{i} = data_test(j,i);
        end
        
        %update engine with new evidence and compile
        [engine, ll] = enter_evidence(engine, evidence);
        %find marginal probabilities of class node
        marg = marginal_nodes(engine,d+1);

        %test if class with highest probability is correct
        %c_hat = find(marg.T >= max(marg.T))-1;
        c_hat = find(marg.T >= max(marg.T));
        if c_hat ~= data_test(j,d+1)
            error = error+1;
        end
        
    end    
    error = error/length(data_test);
    errs(cvn) = error;
    fprintf('Err (fold %g)= %g\n',cvn, errs(cvn));
end%for cvn
err = sum(errs)/10;
fprintf('Err = %g\n',err);






