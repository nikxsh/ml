clear all
close all
clc

%discrete data set names
ddsnames = {'splice.txt'};
%continuous data set names
cdsnames = {'iris.txt','artificial1.txt','artificial2.txt','splice.txt','ionosphere.txt'};

%classify discrete
for dsitr=1:length(ddsnames)
    fprintf('%s\n',ddsnames{dsitr});
    [discerr(dsitr) disc_errs{dsitr}] = naivebn_ml_disc(ddsnames{dsitr});
    fprintf('NBNetwork(disc)   err = %g\n',discerr);       
end

%classify continuous
for dsitr=1:length(cdsnames)
    fprintf('%s\n',cdsnames{dsitr});
    [conterr(dsitr) cont_errs{dsitr}] = naivebn_ml_cont(cdsnames{dsitr});
    fprintf('NBNetwork(cont)   err = %g\n',conterr);        
end

fprintf('Summary:\n');
%print results (discrete)
for dsitr=1:length(ddsnames)
    fprintf('%s\n',ddsnames{dsitr});
    fprintf('NBNetwork(disc)   err = %g\n',discerr(dsitr));       
end

%print results (continuous)
for dsitr=1:length(cdsnames)
    fprintf('%s\n',cdsnames{dsitr});    
    fprintf('NBNetwork(cont)   err = %g\n',conterr(dsitr));
end


