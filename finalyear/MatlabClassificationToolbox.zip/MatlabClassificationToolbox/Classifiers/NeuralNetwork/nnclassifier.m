%Multi-layer Perceptron Implementation

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More information available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%Notation:
%i=1,...,d (nodes in input layer = no variables)
%j=1,...,M (nodes in hidden layer)
%k=1,...,C (nodes in output layer = no classes)
%i - refers to input layer
%j - refers to hidden layer
%k - refers to output layer
%x - input values (1,..,d)
%z - hidden layer input values (1,...,M)
%y - output layer values (1,...,C)
%aj - linear sum of the jth hidden unit [4.2]
%zj - activation/output of jth hidden unit (zj = g1(aj)) [4.3]
%ak - linear sum of the kth output unit [4.5]
%yk - activation/output of the kth output unit (yk = g2(ak)) [4.6]
%wji - a weight going from input unit i to hidden unit j

clear;
clc;
close all;

%Define training data
d = 4;%dimensionality
M = 10;%nodes in hidden layer
C = 3;%number of classes
N = 150; %the number of observations in the training set
data = load('iris.txt'); %load the training data (in array called data)

%Normalise the data
data = ns_data(data);

%Make sure the classes are labeled from 1,...,C
if min(data(:,d+1)) == 0
    data(:,d+1) = data(:,d+1)+1;
end%if

%Define the classifier
%If lr too small, the search will proceed extremely slowly, leading 
%too long convergance times
%If lr is to large, the algorithm may overshoot, leading to an 
%increase in E (error-rate)
%If lr is constant, convergence is not guarenteed
%Can choose lr = 1/stepno to ensure convergence, the convergence may
%however be very slow
%learning parameter for the gradient-descent procedure
lr = 0.001;%for seq
%lr = 0.12;%for bat

maxepochs = 100000;
%update of weights
update = 'bat';%either 'seq'-sequential or 'bat'-batch

%Weight initialisation
clcov=get_clcov(data);%get class covariances
%determine average class covariance
avgcov = zeros(d,d);
for citr=1:C
    avgcov = avgcov+clcov{citr};
end
avgcov = avgcov./C;
%determine average class standard deviation
sd = 0;
for sitr=1:d
    sd = sd+avgcov(sitr,sitr);
end
sd = sd./d;

delt = 1;

%[Mxd]
%getsigns generates an [nxm] matrix with random -1's and 1's
wji = (getsigns(M,d).*delt).*rand(M,d);%initialise first layer of weights with values [-delt,delt]
%[CxM]
wkj = (getsigns(C,M).*delt).*rand(C,M);%initialise second layer of weights with values [-delt,delt]
%initialise the bias unit weights
wji0 = getsigns(1,1).*delt.*rand();
wkj0 = getsigns(1,1).*delt.*rand();

%Feed Forward
%The output of the jth hidden unit is obtained by first forming a weighted
%linear combination of the d input values and adding a bias
%An extra input variable x0 may be included with constant value x0=1 to
%absorb the bias into the weights

for epoch=1:maxepochs
    %fprintf('Epoch: %g\n',epoch);
    sumji = zeros(M,d);%sum of layer 1 deltaj(j,1)*x(i)
    sumkj = zeros(C,M);%sum of layer 2 deltak(j,1)*zj(j,1)
acnt = 0;%accuracy counter
for n=1:N

x = data(n,1:d);%copy the obsn'th observation into array x
%Use a 1-to-C coding scheme
%e.g. 1 = [1 0 0]', 2 = [0 1 0]', 3 = [0 0 1]'
tk = zeros(C,1);
%Classes are coded from 1,...,C
tkval = data(n,d+1);%the class of the observation 
tk(tkval,1) = 1;

%Calculate the weighted sum for each hidden layer unit
%x is a single observation from the training set 
aj = zeros(M,1);
for j=1:M
    wsum = 0;
    for i=1:d
        wsum = wsum + wji(j,i)*x(i);        
    end%i
    wsum = wsum + wji0*1;%add the bias term
    aj(j,1)=wsum;
end%j

%Calculate the activations/outputs of the hidden layer nodes
zj = zeros(M,1);
for j=1:M
    zj(j,1) = gsig(aj(j,1));
end

%The outputs of the network are obtained by transforming the activations of
%the hidden units  using a second layer of processing units
%For each output unit k, we construct a linear combination of the outputs
%of the hidden units 

%Calculate the weighted sum of the output layer nodes
ak = zeros(C,1);
for k=1:C
    wsum = 0;
    for j=1:M
        wsum = wsum + wkj(k,j)*zj(j,1);
    end%i
    wsum = wsum + wkj0*1;%add the bias
    ak(k,1)=wsum;
end%j

%The output/activation of the kth output unit is then obtained by
%transforming this linear combination using a non-linear activation
%function (This activation function may be different from the activation 
%function used in the hidden layer)

%Calculate the activations/outputs of the output layer nodes
yk = zeros(C,1);
for k=1:C
    yk(k,1) = gsig(ak(k,1));
end

%yk - response of output unit k
%tk - corresponding target value for a particular input pattern xn
%Calculate the standard sum-of-squares error for the n'th pattern/observation
esum=0;
for k=1:C
    esum = esum + (yk(k) - tk(k))^2;
end
En(n)=0.5*esum;

%delta's for output units
deltak =zeros(C,1);
for k=1:C
    deltak(k,1) = yk(k) - tk(k);
end

%the delta's for the hidden units are given by
deltaj = zeros(M,1);
for j=1:M
    jsum=0;
    for k=1:C
        jsum = jsum + wkj(k,j)*deltak(k,1);
    end
      
    deltaj(j,1) = zj(j,1)*(1-zj(j,1))*jsum;
end

%The derivatives with respect to the first-layer and second-layer weights

%Calculate the dwji values and update wji
%Update the first layer weights - add the delta values to wji
for j=1:M
    for i=1:d
        dwji(j,i) = -lr*deltaj(j,1)*x(i);
        if update == 'seq'%update the weights
            %if j==1&i==1 fprintf('Updating 1st layer weights!\n');end
            wji(j,i) = wji(j,i)+dwji(j,i);
        end%if
        sumji(j,i) = sumji(j,i) + deltaj(j,1)*x(i); 
    end
end

%and the weights for the second layer are updated using
for k=1:C
    for j=1:M
        dwkj(k,j) = -lr*deltak(k,1)*zj(j,1);
        if update == 'seq'
            %if k==1& j==1 fprintf('Updating 2nd layer weights!\n');end
            wkj(k,j) = wkj(k,j)+dwkj(k,j);
        end%if
        sumkj(k,j) = sumkj(k,j) + deltak(k,1)*zj(j,1);
    end
end

%choose an observation of each class to monitor covergence of classes
if (n==1|n==N|n==75)&(mod(epoch,100)==0)
    fprintf('After %g epochs:\n', epoch);
    fprintf('Error for pattern %g = %g\n',n, En(n));     
end%if

cloutp = zeros(1,C);%the classifier output
toutp = zeros(1,C);%the tatget output
for k=1:C
    cloutp(1,k)=yk(k);
    toutp(1,k)=tk(k);
end
[clv cli]=max(cloutp);
[tv ti]=max(toutp);
if cli==ti
    acnt = acnt+1;%correct label
end%if

end%n=1:N

%Calculate the accuracy for this epoch
if (mod(epoch,100)==0)
    %cloutp
    %toutp
    eacc = acnt/N*100
    ep_acc(epoch/100)= eacc;
end

%For batch learning:
if update == 'bat'    
for j=1:M
    for i=1:d
        dwji(j,i) = -lr*sumji(j,i);
        wji(j,i) = wji(j,i)+dwji(j,i);
    end
end

%and the weights for the second layer are updated using
for k=1:C
    for j=1:M
        dwkj(k,j) = -lr*sumkj(k,j);
        wkj(k,j) = wkj(k,j)+dwkj(k,j);
    end
end
end%if update == 'bat'
end%epochs