function dat = ns_data(data)
%Normalise data by dividing each variable by its maximum value

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More information available at http://www.patternrecognition.co.za

novar = size(data,2)-1;%last column contains the class labels

mxv = max(abs(data(:,1:novar)));
for itr=1:size(data,1)
    dat(itr,1:novar) = data(itr,1:novar)./mxv;
end
dat(:,novar+1)=data(:,novar+1);