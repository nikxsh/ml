function data = binclas(datao, c1, c2)
%Extracts only the data for the two classes specified

%get the indices
c1idx = find(datao(:,end)==c1);
c2idx = find(datao(:,end)==c2);

%change the class labels
datao(c1idx,end) = 1;
datao(c2idx,end) = 2;

%concatenate the data
data = datao(c1idx,:);
data = [data; datao(c2idx,:)];


