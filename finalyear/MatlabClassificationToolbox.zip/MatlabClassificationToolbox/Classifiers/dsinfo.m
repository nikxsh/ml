function [data, d, N, C] = dsinfo(data)
[N, dt] = size(data);
d = dt-1;

if min(data(:,end)) == 0
    C = max(data(:,end))+1;
    data(:,end) = data(:,end)+1;
else
    C = max(data(:,end));    
end