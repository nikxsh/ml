function dat = getcldat(data, citr)
%Returns all the instances of a specific class

clidx = find(data(:,end)==citr);
dat = data(clidx, :);
