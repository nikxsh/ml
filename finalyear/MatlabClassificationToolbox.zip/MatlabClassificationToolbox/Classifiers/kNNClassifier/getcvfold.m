%Divides the data into a training and testing set
%9 folds are used for training and 1 fold is used for testing

%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

ds = ones(1,10);%flags to mark training folds
ds(cvn) = 0;%0 is the testing fold
te_idx = cvn;
tr_idx = find(ds == 1);

data_tr = [];
for fitr=1:9
    data_tr = [data_tr; fold{tr_idx(fitr)}]; 
end
data_te = fold{te_idx};