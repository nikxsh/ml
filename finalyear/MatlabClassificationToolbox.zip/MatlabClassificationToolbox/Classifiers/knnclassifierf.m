function [err optK knnerrs] = knnclassifierf(dsn, kmin,kinc,kmax)
%k-nearest-neighbour classifier

%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%See Bishop p.55
%fix K and allow the volume V to vary
%one of the applications of density estimation is the construction of
%classifiers through the use of Bayes' theorem. This invloves the moddeling
%of the class-conditional densities for each class seperately, and then
%combining them with priors to give models for the posterior probabilities
%which can then be used to make classification decisions

%Consider a small hyper-sphere centered at the point x, and allow the
%radius of the sphere to grow until it contains precisely K data points.
%The estimate of the density of the point is then given by [2.53]

%[2.53]
%p(x)=K/(NV)

%We can use [2.53] to give approximations of the class-conditional
%densities in the form

%[2.62]
%The sphere has volume V and contains Kk points from class Ck.
%There are Nk points in class k

%The unconditional density can be estimated from [2.63] but is also given
%by [2.53]

%The priors can be estimated using p(Ck)=Nk/N [2.64]

%Bayes' theorem can now be used to give [2.65]
%P(Ck|x)=Kk/K

%Thus to minimise the probability of misclassifying a new vector x, it
%should be assigned to the class Ck for which the ratio Kk/K is largest

%Distance metric
%Euclidean
%See Webb p.420
%See edist(x,y)

%clear;
%close all;

%Classifier settings
%kmax = 10;
%data = load('iris.txt');
data = load(dsn); 
res_ties = 1;%if == 1 then resolves ties with nearest class mean else choose the lowest class label             
weighnn = 0;%make training samples closer to the observation count more
d = size(data,2)-1;%the dimensionality of the data
N = size(data,1);%the number of samples in the data set

%Determine the number of classes
if min(data(:,d+1)) == 0
    data(:,d+1)=data(:,d+1)+1;
    C = max(data(:,d+1));
else
    data(:,d+1)=data(:,d+1);%-1;
    C = max(data(:,d+1));    
end

%if the nearer neighbours should have more weight in the decisions
if weighnn == 1
    wd=100;%the weight differnce between neighbours eg. =2 then 20, 18, 16 ect.
    cidxwts = wd*kmax:-wd:1;%the weights of the neighbours
end

for K=kmin:kinc:kmax
%fprintf('.');
%Perform cross-validation
taccuracy = zeros(1,10);%contains the accuracies of each fold
for cvn=1:10
cvalid
getcvfold
clm = get_clmeans(data_tr);   
    %Classify the test set
    for titr=1:size(data_te,1)%size(itest,1)
        x = data_te(titr,1:d);       
        %Calculate the euclidean distance to all the observations in the
        %training set
        distances= zeros(size(data_tr,1));        
        for tritr=1:size(data_tr,1)
            y = data_tr(tritr,1:d);            
            distances(tritr) = edist(x,y);            
        end%for
        [B, IX] = sort(distances, 'ascend');
        nearestobs = IX(1:K);%contains the indexes of the K-nearest-neighbours
        nearestobsd = B(1:K);%K nearest observations distances
        classnobs = data_tr(nearestobs,d+1);
        
        testres{titr,1}=titr;
        testres{titr,2}=nearestobsd;
        testres{titr,3}=nearestobs;
        testres{titr,4}=classnobs;
               
        %Classify the samples
        cfreq = zeros(1,C);
             
        for citr=1:C
            votes = []; cidx = [];
            votes = testres{titr,4};
            cidx = find(testres{titr,4}==citr);
            if weighnn == 1%add weights to the neighbours votes
                wvotes = cidxwts(cidx);
            else%no weights, just count the NN votes
                wvotes = length(cidx);
            end
            cfreq(citr)=sum(wvotes);
            
        end%for
        
        testres{titr,7}=cfreq;%weighted vote
                
        [m, ind] = max(cfreq);%determine the class with most votes
        %Determine if there was a tie
        if length(find(cfreq==m)) >1
            tidx = find(cfreq==m);%indices of ties            
            noties = length(find(cfreq==m));
            tdifs = zeros(1,noties);
            for titr=1:noties
                t1 = clm{tidx(titr)};%the mean vector of the tied class
                %calculate the euclidean distance between the observation
                %that has ties and the means of the tied classes
               tdifs(titr) = edist(x,t1);
            end%for
            %determine the nearest class mean to the tied observation
            [wed, wind] = min(tdifs); 
            if res_ties == 1
                ind = tidx(wind);
            end
        end%if
        
        testres{titr,5} = ind;%the classified label for test instance titr
        testres{titr,6} = data_te(titr,d+1);%the actual class label          
        
    end%titr
        %Copy the actual class labels
        clear tmp1 tmp2
        %testres
        for itr=1:size(data_te,1)
            tmp1(itr) = testres{itr,5};
            tmp2(itr) = testres{itr,6};
        end
        %Calculate error rate for this fold
        terrs = length(find((tmp1-tmp2)~=0));
        cverr = terrs/size(data_te,1);
        fprintf('%g\n',cverr);
        taccuracy(cvn) = 100 - terrs/size(data_te,1)*100;
end%subn
        clear tmpe tmpr etmp1 etmp2 errmat errmatl
        testacc(K) = sum(taccuracy)/10;%10-fold cv accuracy for this K value                
        fprintf('Err(k = %g) = %g\n',K,1-testacc(K)/100);
end%K=1:kmax

knnerrs = 1 - testacc./100;
[err optK] = min(knnerrs);
%fprintf('\nTest accuracies for k=1,...,k=%g:\n',kmax);
%disp(testacc);
