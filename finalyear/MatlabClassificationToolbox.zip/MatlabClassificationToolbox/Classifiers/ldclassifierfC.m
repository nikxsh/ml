function [clerrw werr err totdist trackidx] = ldclassifierfC(dsn)
%Multi Class Linear Discriminant Classifier 
%Based on Fishers Linear discriminant (Least Squares error estimation)

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

datao = load(dsn);
cntr=1;
if min(datao(:,end)) == 0
    CA = max(datao(:,end))+1;
    datao(:,end) = datao(:,end)+1;
else
    CA = max(datao(:,end));    
end
C = 2;%Divide into 2 class problems


for(citr1=1:CA)
for(citr2=(citr1+1):CA)
trackidx(cntr,1)=citr1;%tells you which boundary is being considered
trackidx(cntr,2)=citr2;
data = binclas(datao, citr1, citr2);
N = size(data,1);
d = size(data,2)-1;
totdist(cntr) = 0;
Ncomb(cntr)=0;

%Split the data into folds
%find the indices of the classes
for idxitr=1:C
    idxs{idxitr} = find(data(:,d+1)==idxitr);
end%for
%find out how many the test/validation observations are 
%required from each class
for idxitr=1:C
    csize(idxitr) = length(idxs{idxitr})./10;
end%for

for critr=1:10%cross-validation
%extract one of 10 folds of the data
tempd = [];
for clitr=1:C
    t_tidx = idxs{clitr};%the indices of all samples of this class
    tidx = t_tidx(floor(csize(clitr)*(critr-1)+1):floor(critr*csize(clitr)));%the indices of the test samples to be used of this class
    %tidx = t_tidx(csize(clitr)*(critr-1)+1:critr*csize(clitr));%the indices of the test samples to be used of this class
    tempd = [tempd; data(tidx,:)];
end%for te
fold{critr} = tempd;
end%for critr

for cvn=1:10
ds = ones(1,10);%flags to mark training folds
ds(cvn) = 0;%0 is the testing fold
te_idx = cvn;
tr_idx = find(ds == 1);

data_tr = [];
for fitr=1:9
    data_tr = [data_tr; fold{tr_idx(fitr)}]; 
end
data_te = fold{te_idx};
    
for cln=1:C
    nidx{cln} = find(data_tr(:,d+1)== cln);
    Xn = data_tr(nidx{cln},1:d);%data for class cln
    n{cln} = length(nidx{cln});
    %class mean
    m{cln}=sum(Xn)./(n{cln});
    Xnprod{cln} = Xn'*Xn;
end

%sample mean
Msum = 0;
for cln=1:C
    Msum = Msum + n{cln}*m{cln}; 
end
M = Msum/N;

%The common covariance matrix
Sw = 1/N*(Xnprod{1}+Xnprod{2}-n{1}*m{1}*m{1}' - n{2}*m{2}*m{2}');
Swinv = inv(Sw);
    
acc = 0;
c1dist = 0;
c2dist = 0;
for itr=1:size(data_te,1)
    x = data_te(itr,1:d);
    dect(itr) = (Swinv*(m{1}'-m{2}'))'*(x'-M');
    p1 = n{1}/N;
    p2 = n{2}/N;
    d2 = (m{1}'-m{2}')'*inv(Sw)*(m{1}'-m{2}');
    thr = ((p2-p1)/2)*((1+p1*p2*d2)/(p1*p2));
    if dect(itr) < thr
        cl_lab(itr)=2;
        dist = thr - dect(itr);%distance of sample form decision boundary
        %Determine how far a sample is from the decision boundary
        if cl_lab(itr) == data_te(itr,d+1)
            c1dist = c1dist + dist;%correct decision has positive dist
        else
            c1dist = c1dist - dist;
        end%if        
    else
        cl_lab(itr)=1;
        dist = dect(itr)-thr;
        %Determine how far a sample is from the decision boundary
        if cl_lab(itr) == data_te(itr,d+1)
            c2dist = c2dist + dist;%correct decision has positive dist
        else
            c2dist = c2dist - dist;
        end%if                
    end%if
    if cl_lab(itr) == data_te(itr,d+1)
        acc = acc+1;
    end%if
        
end%for   
%acc
accuracy(cvn) = acc/size(data_te,1)*100;    
Ncomb(cntr)=Ncomb(cntr)+size(data_te,1);%for weighing
totdist(cntr) = totdist(cntr)+c1dist+c2dist;
end%cvn

Ncomb(cntr)=Ncomb(cntr)/cvn;%average test set size
totdist(cntr)=totdist(cntr)/(cvn*Ncomb(cntr));%normalize dist with samples
acr(cntr) = sum(accuracy)/10;
err(cntr) = 1 - acr(cntr)/100;

cntr = cntr+1;
end%citr1
end%citr2

%err(cntr) - Each of these error rates are between different classes
%If these values are not homogeneious, the SVM will have trouble
%with optimizing its C value

%To get the final error rate, the err(cntr) values must be normalized
%according to how many samples played a role
Ntot = sum(Ncomb);
Ncombw = Ncomb./Ntot;


for itr=1:length(err)
    werr(itr) = err(itr)*Ncombw(itr);
end

%clerr = sum(err)/length(err)
clerrw = sum(werr);

%Measure of how linearly seperable the data is (how far the samples are from the decision boundary)
%Normalize this measure by taking into account the size of the feature
%space
datai = datao(:,1:d);
vmin = min(datai);
vmax = max(datai);
ln = edist(vmin,vmax);%diagonal distance of feature space
totdist = totdist./ln;

%err is the percentage error that occured at each decision boundary
%werr is the weighed percentage error that occured at each decision
%boundary, the error is weighed by the number of samples involved
%totdist is a normalized measure of how linearly seperrable the data is at
%the boundaries

