function err = lgclassifierf(dsn)
%Two Class Linear Classifier 
%Assuem Gaussian distributed classes with common covariance matrix

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%clear
%data = load('australian.txt');
data = load(dsn);
N = size(data,1);
d = size(data,2)-1;
if min(data(:,end)) == 0
    C = max(data(:,end))+1;
    data(:,end) = data(:,end)+1;
else
    C = max(data(:,end));    
end

%Split the data into folds
%find the indices of the classes
for idxitr=1:C
    idxs{idxitr} = find(data(:,d+1)==idxitr);
end%for
%find out how many the test/validation observations are 
%required from each class
for idxitr=1:C
    csize(idxitr) = length(idxs{idxitr})./10;
end%for

for critr=1:10%cross-validation
%extract one of 10 folds of the data
tempd = [];
for clitr=1:C
    t_tidx = idxs{clitr};%the indices of all samples of this class
    tidx = t_tidx(floor(csize(clitr)*(critr-1)+1):floor(critr*csize(clitr)));%the indices of the test samples to be used of this class
    %tidx = t_tidx(csize(clitr)*(critr-1)+1:critr*csize(clitr));%the indices of the test samples to be used of this class
    tempd = [tempd; data(tidx,:)];
end%for te
fold{critr} = tempd;
end%for critr

for cvn=1:10
ds = ones(1,10);%flags to mark training folds
ds(cvn) = 0;%0 is the testing fold
te_idx = cvn;
tr_idx = find(ds == 1);

data_tr = [];
for fitr=1:9
    data_tr = [data_tr; fold{tr_idx(fitr)}]; 
end
data_te = fold{te_idx};

for cln=1:C
    nidx{cln} = find(data_tr(:,d+1)== cln);
    Xn = data_tr(nidx{cln},1:d);%data for class cln
    n{cln} = length(nidx{cln});
    %class mean
    m{cln}=sum(Xn)./(n{cln});   
end

clcov = get_clcov(data_tr);

N = size(data_tr,1);
Sw =zeros(d,d);
for cln=1:C
    Sw = Sw + n{cln}/N*clcov{cln};
end
Sw = N/(N-C)*Sw;%the unbiased estimate

Nte = size(data_te,1);
gx = zeros(Nte,C);
for itr=1:Nte
    x = data_tr(itr,1:d);
    for cln=1:C       
        gx(itr,cln)=log(n{cln}/Nte)-0.5*(m{cln})*(inv(Sw))*(m{cln}')+ x*inv(Sw)*m{cln}';
    end        
end
[clv clb]=max(gx');%class labels
accuracy(cvn) = 100 - length(find(clb' ~= data_te(:,d+1)))/Nte*100;
end%subn

%accuracy of all the data
acr = sum(accuracy)/10;
err = 1 - acr/100;