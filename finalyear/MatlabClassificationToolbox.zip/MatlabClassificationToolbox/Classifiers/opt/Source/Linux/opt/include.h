/*
** include.h --
**	Pieter se standaard kop
*/

/* Include files */
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <malloc.h>

/* User-defined functions */
#define max(a,b)	((a)<(b)?(b):(a))
#define min(a,b)	((a)<(b)?(a):(b))
#define bound(a,b,c)	(max((a),min((b),(c))))
#define round(a) ((a)>0? (int)((a)+.5):(int)((a)-.5))
#define hi(a)		(unsigned char)(a/256)
#define lo(a)		(unsigned char)(a%256)
#define sqr(a)		((a) * (a))

/* Type definitions */
typedef unsigned char	byte;
typedef struct COMPLEX{
	double r,i;
} complex;
typedef struct FCOMPLEX{
	float r,i;
} fcomplex;




