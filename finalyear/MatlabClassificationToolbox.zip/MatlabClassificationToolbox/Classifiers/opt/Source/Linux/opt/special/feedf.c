#include "include.h"
#include "allocspace.c"
#define RMAX 16383.5
#define EMAX 50
#define EMIN -50
#define DATA "clas.da"
#define WT "opt.o"
#define OUT "nout."

extern char **alloc2d();
extern char ***alloc3d();

float ***w, **act, **delt, **inact;
int nlayers, nin, *sz, *clas;
FILE *inp, *outp, *datp;

float 
f(s)
  float s;
{
  float x;

  x = s;
  if (x > EMAX)
    x = EMAX;
  else if (x < EMIN)
    x = EMIN;
  return (float) 1. / (1. + exp(-x));
}

void 
eerror(where)
  char *where;
{
  perror(where);
  exit(1);
}

/** Calculate output of net for input # iin **/
void 
up_act(iin)
{
  int i1, i2, il, ct;
  float s;

  for (i2 = 0; i2 < sz[1]; i2++) {
    s = 0.;
    for (i1 = 0; i1 < sz[0]; i1++)
      s += w[0][i2][i1] * inact[iin][i1];
    act[1][i2] = f(s);

  }
  for (il = 1; il < nlayers - 1; il++)
    for (i2 = 0; i2 < sz[il + 1]; i2++) {
      s = 0.;
      for (i1 = 0; i1 < sz[il]; i1++)
	s += w[il][i2][i1] * act[il][i1];
      act[il + 1][i2] = f(s);
    }
}

main(argc, argv)
  int argc;
  char **argv;
{
  float temp, fmax, fmin, amax, err;
  int iin, iit, il, i, i1, i2, szmax, finsz, cl, **confn, cmax, j, nl1;
  char name[100];
  float grootste;
  int grootsteLabel;

  if (argc != 3) {
    printf("Usage:weightfile# datafile#\n");
    return;
  }
  strcpy(name, WT);
  if (!(inp = fopen(strncat(name, argv[1], 2), "r")))
    eerror("infile");

/*  strcpy(name, OUT);
  if (!(outp = fopen(strncat(name, argv[2], 2), "w")))
    eerror("outfile");
*/
  strcpy(name, DATA);
  if (!(datp = fopen(strncat(name, argv[2], 2), "r")))
    eerror("datfile");

  fread(&iit, sizeof(int), 1, inp);

  fread(&nlayers, sizeof(int), 1, inp);
  if (!(sz = (int *) malloc(nlayers * sizeof(int))))
    eerror("sz");

  fread(sz, sizeof(int), nlayers, inp);
  nl1 = nlayers - 1;

  szmax = 0;
  for (il = 0; il < nlayers; il++)
    if (sz[il] > szmax)
      szmax = sz[il];
  fscanf(datp, " %d", &nin);
  /** confn contains confusion matrix; for other definitions see opt.c **/
  if (!(clas = (int *) malloc(nin * sizeof(int))))
    eerror("clas");
  if (!(inact = (float **) alloc2d(nin, sz[0], sizeof(float))))
    eerror("inact");
  if (!(act = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("act");
  if (!(delt = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("delt");
  if (!(w = (float ***) alloc3d(nl1, szmax, szmax, sizeof(float))))
    eerror("w");

  for (il = 0; il < nl1; il++)
    for (i1 = 0; i1 < sz[il + 1]; i1++)
      fread(w[il][i1], sizeof(float), sz[il], inp);

  fread(&err, sizeof(float), 1, inp);
/*  printf("err=%f\n", err);*/

  for (iin = 0; iin < nin; iin++) {
    fscanf(datp, "%d", &clas[iin]);
    if (clas[iin] > sz[nl1])
      eerror("More classes than output neurons");
    for (i1 = 0; i1 < sz[0] - 1; i1++)
      if (fscanf(datp, "%f", &inact[iin][i1]) == EOF)
	eerror("Insufficient data");
    inact[iin][sz[0] - 1] = 1.;
  }

  finsz = sz[nl1];
  for (iin = 0; iin < nin; iin++) {
	grootste=0;
    up_act(iin);
    cl = clas[iin] - 1;
    for (i = 0; i < finsz; i++)
	{
		if (act[nlayers - 1][i]>grootste)
		{
			grootste=act[nlayers - 1][i];
			grootsteLabel=i+1;
		}
	}
	printf("%d\n",grootsteLabel);
	/*
    for (i = 0; i < finsz; i++) fprintf(outp,"%5.3f ",act[nlayers - 1][i]);
    fprintf(outp,"\n");
	*/
  }
}
