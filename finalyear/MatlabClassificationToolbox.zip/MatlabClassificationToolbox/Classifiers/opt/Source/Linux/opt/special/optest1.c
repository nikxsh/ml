/* Spesiale weergawe van optest vir deBeers werk; skryf uit hoeveel */
/* kere elke uitsetneuron binne 'n reeks van uitsetwaardebins van van */
/* 0 tot 1 */

#include <include.h>
#define RMAX 16383.5
#define EMAX 50
#define EMIN -50
#define DATA "clas.da"
#define WT "opt.o"
#define OUT "test."

extern char **alloc2d();
extern char ***alloc3d();

float ***w, **act, **delt, **inact;
int nlayers, nin, *sz, *clas;
FILE *inp, *outp, *datp;

float 
f(s)
  float s;
{
  float x;

  x = s;
  if (x > EMAX)
    x = EMAX;
  else if (x < EMIN)
    x = EMIN;
  return (float) 1. / (1. + exp(-x));
}

void 
eerror(where)
  char *where;
{
  perror(where);
  exit(1);
}

/** Calculate output of net for input # iin **/
void 
up_act(iin)
{
  int i1, i2, il, ct;
  float s;

  for (i2 = 0; i2 < sz[1]; i2++) {
    s = 0.;
    for (i1 = 0; i1 < sz[0]; i1++)
      s += w[0][i2][i1] * inact[iin][i1];
    act[1][i2] = f(s);

  }
  for (il = 1; il < nlayers - 1; il++)
    for (i2 = 0; i2 < sz[il + 1]; i2++) {
      s = 0.;
      for (i1 = 0; i1 < sz[il]; i1++)
	s += w[il][i2][i1] * act[il][i1];
      act[il + 1][i2] = f(s);
    }
}


/* getBin : Find the index of the bin number which the input falls */
/* into. Bins are numbered from 0 to 9 , and represent the ranges 0 to */
/* 0.1, 0.1 to 0.2, ..., 0.9 to 1.0 */
int getBin(float inVal)
{
/* This long string of ifs is preferred above a mathematical */
/* expression converting the input value to a bin number for the sake */
/* of generality of future bin ranges, numbers, etc. */
    if (inVal<=0.1)
	  return 0;
    else
    if (inVal<=0.2)
	  return 1;
    else
    if (inVal<=0.3)
	  return 2;
    else
    if (inVal<=0.4)
	  return 3;
    else
    if (inVal<=0.5)
	  return 4;
    else
    if (inVal<=0.6)
	  return 5;
    else
    if (inVal<=0.7)
	  return 6;
    else
    if (inVal<=0.8)
	  return 7;
    else
    if (inVal<=0.9)
	  return 8;
    else
    if (inVal<=1.0)
	  return 9;
}

/* getBin2 : Find the index of the bin number which the input falls */
/* into. Bins are numbered from 0 to 3 , and represent the ranges 0 to */
/* 0.1, 0.1 to 0.5, 0.5 to 0.9, 0.9 to 1.0 */
int getBin2(float inVal)
{
/* This long string of ifs is preferred above a mathematical */
/* expression converting the input value to a bin number for the sake */
/* of generality of future bin ranges, numbers, etc. */
    if (inVal<=0.1)
	  return 0;
    else
    if (inVal<=0.5)
	  return 1;
    else
    if (inVal<=0.9)
	  return 2;
    else
    if (inVal<=1.0)
	  return 3;
}

main(argc, argv)
  int argc;
  char **argv;
{
  float temp, fmax, fmin, amax, err;
  int iin, iit, il, i, i1, i2, szmax, finsz, cl, **confn, cmax, j, nl1;
  char name[100];
  long nPlus[5][10], nMin[5][10]; /* Keep count of chosen classes (cjb */
		      /* 8/1/95) */
  float app;	/* A postiori probability */

  if (argc != 3) {
    printf("Usage:inputfile# testfile#\n");
    return;
  }
  strcpy(name, WT);
  if (!(inp = fopen((char *)strncat(name, argv[1], 3), "r")))
    eerror("infile");

  strcpy(name, OUT);
  if (!(outp = fopen((char *)strncat(name, argv[2], 3), "w")))
    eerror("outfile");

  strcpy(name, DATA);
  if (!(datp = fopen((char *)strncat(name, argv[2], 3), "r")))
    eerror("datfile");

  fread(&iit, sizeof(int), 1, inp);

  fread(&nlayers, sizeof(int), 1, inp);
  if (!(sz = (int *) malloc(nlayers * sizeof(int))))
    eerror("sz");

  fread(sz, sizeof(int), nlayers, inp);
  nl1 = nlayers - 1;

  szmax = 0;
  for (il = 0; il < nlayers; il++)
    if (sz[il] > szmax)
      szmax = sz[il];
  fscanf(datp, " %d", &nin);
  /** confn contains confusion matrix; for other definitions see opt.c **/
  if (!(confn = (int **) alloc2d(sz[nl1], sz[nl1], sizeof(int))))
    eerror("confn");
  if (!(clas = (int *) malloc(nin * sizeof(int))))
    eerror("clas");
  if (!(inact = (float **) alloc2d(nin, sz[0], sizeof(float))))
    eerror("inact");
  if (!(act = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("act");
  if (!(delt = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("delt");
  if (!(w = (float ***) alloc3d(nl1, szmax, szmax, sizeof(float))))
    eerror("w");

  for (il = 0; il < nl1; il++)
    for (i1 = 0; i1 < sz[il + 1]; i1++)
      fread(w[il][i1], sizeof(float), sz[il], inp);

  fread(&err, sizeof(float), 1, inp);
  printf("err=%f\n", err);

  for (iin = 0; iin < nin; iin++) {
    fscanf(datp, "%d", &clas[iin]);
    if (clas[iin] > sz[nl1])
      eerror("More classes than output neurons");
    for (i1 = 0; i1 < sz[0] - 1; i1++)
      if (fscanf(datp, "%f", &inact[iin][i1]) == EOF)
	eerror("Insufficient data");
    inact[iin][sz[0] - 1] = 1.;
  }

  /* Initialize variables used in confidence indicator experiments */
  finsz = sz[nl1];
  for (i=0;i<finsz;i++)
    for (i1=0;i1<10;i1++)
      nPlus[i][i1]=nMin[i][i1]=0;

  for (iin = 0; iin < nin; iin++) {
    up_act(iin);
    cl = clas[iin] - 1;
    /** find most active output neuron **/
    amax = act[nlayers - 1][0];
    cmax = 0;
    for (i = 1; i < finsz; i++)
      if (act[nlayers - 1][i] > amax) {
	amax = act[nlayers - 1][i];
	cmax = i;
      }
    for (i = 0; i < finsz; i++)
	{
	if (i==clas[iin]-1)
		nPlus[i][getBin2(act[nlayers - 1][i])]++;
	else
		nMin[i][getBin2(act[nlayers - 1][i])]++;
	}
    /** increment appropriate counter in confusion matrix **/
    confn[cl][cmax]++;
/* CJB 8/1/95 : Now check the activity level of the output neuron */
/* representing the chosen class. */
/*printf("%d %d %f\n",cmax,getBin(act[nlayers-1][cmax]),act[nlayers-1][cmax]);*/

/* CJB 21/02/95 : Nope; ECB & EB wants all activities to be counted; not
					only the winning ones 
	if (cmax==clas[iin]-1)
	    nPlus[cmax][getBin(act[nlayers - 1][cmax])]++;
	else
	    nMin[cmax][getBin(act[nlayers - 1][cmax])]++;
  */
  }

	
  /** compute total # correctly classified **/
  amax = 0;
  for (i = 0; i < finsz; i++)
    amax += confn[i][i];

  printf("%% correct= %5.2f\n", 100. * amax / nin);

/* Output CJB experiment */
  printf("\n");
  
  for (i=0; i<finsz; i++)
    {
    for (i1=0;i1<4;i1++)
	{
	  
	  /*
	  printf("%d %d\n",nPlus[i][i1],nMin[i][i1]);
	  */
	  
	  if ((nPlus[i][i1]+nMin[i][i1]) !=0 )
	{
	  app=nPlus[i][i1]/(float)(nPlus[i][i1]+nMin[i][i1]);
	}
	else
	{
		app=9.;
	}
      printf("%d %f\n",i1,app);
	}
	printf("\n");
}

  fprintf(outp, " # of its.: %d; %% correct= %5.2f\n", iit, 100. * amax / nin);

  fprintf(outp, "label");
  for (i = 0; i < finsz; i++)
    fprintf(outp, " %4i", i + 1);
  fprintf(outp, "\n");
  fprintf(outp, "-----");
  for (i = 0; i < finsz; i++)
    fprintf(outp, " ----");
  fprintf(outp, "\n");
  for (i = 0; i < finsz; i++) {
    fprintf(outp, "%4i:", i + 1);
    for (j = 0; j < finsz; j++)
      fprintf(outp, " %4d", confn[i][j]);
    fprintf(outp, "\n");
  }

}



