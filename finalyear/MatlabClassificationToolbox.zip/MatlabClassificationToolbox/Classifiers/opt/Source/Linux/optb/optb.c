/*
 * OPTB.C
 *
 * Written by  	Etienne Barnard
 * Adapted by   Johan Schalkwyk
 *
 *
 * This program is used to find the set of weights for an
 * arbitrary neural network, in such a manner as to minimize
 * the objective function of the neural network as defined
 * by the input data file.
 *
 * This program makes use of the Conjugate Gradient Descent
 * algorithm as described by
 *
 *		POWELL 1977
 *		Restart Procedure for the
 *		Conjugate Gradient Descent Algorithm
 *
 * Program Use:
 *
 * 	OPTB data_set continue_flag print_flag
 *
 *	data_set: number of file containing data set
 *			CLASB.DA(data_set)
 *	continue_flag: 0 -> restart from random position in space
 *		       1 -> continue from previous training process
 *	print_flag: 0 -> don't print objective function value after each
 *			 iteration
 *		    1 -> print value of objective function after each
 *			 iteration
 *
 *
 *  CLASB.DA(data_set) -- text file
 *
 *  line 1: number of training examples
 *  line 2.. : output vector + input vector
 *
 *
 *  OPTB.DA(data_set) -- text file
 *
 *  line 1: nlayer  iterations   tolerance   seed
 *  line 2: input   first_layer ....  output_layer
 *
 *
 */


/* include file directives */
#include <include.h>

/* Global Constant definition */
#define RMAX 16384.             /** (maximum random number)/2              **/
#define TABSZ 10000		/** number of entries in sigmoid table     **/
#define TABSTEP 0.004		/** increment between entries in table     **/
#define EMAX 20.0		/** cut-off for exp-function 		   **/
#define EMIN -20.0		/** cut-off for exp-function 		   **/
#define CLAS "clasb.da"	/** filename for test samples 	   **/
#define CONST "optb.da"	/** filename for network parameter **/
#define OUTP "optb.o"	/** filename for output 	   **/
#define MAXFEAT 20		/** if any input feature exceeds warn user **/


/* extern routines definition */
extern char **alloc2d();
extern float errfc(), cgrd();

float 	*w;			/* synaptic strength - weight matrix	*/
float 	**act;			/* actions of network matrix		*/
float	alpha;			/* parameter use during line search	*/
float 	*tab;			/* sigmoid table used for neural net    */
float 	**delt;			/* used for gradient calculation	*/
float 	**inact;		/* input actions of neural network	*/
float 	tabsz_2;		/* number of entries in sigmoid table   */
float 	**outact;		/* output actions of neural network	*/
int 	nlayers;		/* number of layers in neural net	*/
int	nin;			/* number of iteration to perform	*/
int	*sz;			/* architecture size definition matrix  */
int 	nl1;			/* number of layers -1; output layer    */
int 	nl2;			/* number of layers -2; hidden layer	*/
int 	*pl;			/* number of connection in network      */
int 	prt_flag;		/* print current energy flag		*/


/*
 * float f(s)
 *
 * This function calculates the sigmoidian value of
 * the input constant, for use of the sigmoid table.
 *
 */

float f(s)
    float s;
{
    float x;

    x = s/*alpha*/ ;
    if (x>EMAX)
      x= EMAX;
    else if (x<EMIN)
      x= EMIN;
    return (float) 1.0/(1.0 + exp(-(float) x));
}


/***** Exit with appropriate error message ******/
void
eerror(where)
  char *where;
{
  perror(where);
  exit(1);
}


/*
 * errfc(w, dw, nconn)
 *
 * This function calculates the value of error function
 * and the value of the gradient of the error function
 * at time t
 *
 * w(in): the weight matrix at time t
 * dw(out): the gradient to return matrix
 * nconn(in): the number of connections in the neural network
 *
 */

float errfc(w, dw, nconn)
  int nconn;	     /** number of connections=dimensionality of w, dw **/
  float *w, *dw;
{
   int i2, il, iin;                    /* loop counters                  */
   int ct;                             /* position in sigmoid table      */
   float s;                            /* output of neuron               */
   float tot_err;                      /* total error so far             */
   register float rfl;                 /* input to neuron                */
   register float *pv1, *pv2, *pend;   /* pointer for matrix handling    */

/** clear dw - gradient matrix fill with zero  **/
  rfl = 0.000;				/* initialize value for dw matrix */
  pv1 = dw;				/* pointer to start of dw matrix  */
  pend = pv1 + nconn;			/* pointer to end of dw matrix    */
  for (; pv1 < pend;)			/* initialize matrix with zero's  */
    (*pv1++) = rfl;

  tot_err = 0.0;			/* initialize total error         */
  for (iin = 0; iin < nin; iin++) {     /* for all learning examples      */
    pend = w;				/* pointer to start of weigts     */

    for (i2 = 0; i2 < sz[1]; i2++) {    /* elements first non-input layer */
      rfl = 0.00;			/* initalize activation of neuron */
      pv1 = pend;			/* pointer start current weights  */
      pend = pv1 + sz[0];		/* pointer end of weights neuron  */
      pv2 = inact[iin];			/* input action of network        */
      for (; pv1 < pend;)		/* for all input units		  */
	rfl += (*pv2++) * (*pv1++);	/* calculate input activation	  */
/*
      ct = rfl / alpha + tabsz_2;        determine position sig table   
      if (ct >= TABSZ)                   if out of bounds keep in bound 
	ct = TABSZ - 1;
      else if (ct < 0)
	ct = 0;
      act[1][i2] = tab[ct];              calculate output of neuron     */
      act[1][i2] = f(rfl);             /* calculate output of neuron     */
    }

    for (il = 1; il < nl1; il++)	/* for all layers upto output     */
      for (i2 = 0; i2 < sz[il + 1]; i2++) { /* for number neurons/layer   */
	rfl = 0.0;			/* initilize neuron activation    */
	pv1 = pend;			/* pointer weights of neurons     */
	pend = pv1 + sz[il];		/* pointer end of weights         */
	pv2 = act[il];			/* input action to current neuron */
	for (; pv1 < pend;)		/* for all neurons connected      */
	  rfl += (*pv1++) * (*pv2++);	/* calculate input activation	  */
	act[il + 1][i2] = rfl;		/* for 3 layer network -- linear  */
      }

    for (i2 = 0; i2 < sz[nl1]; i2++) {  /* calculate gradient objective   */
      rfl=act[nl1][i2]-outact[iin][i2]; /* error betweem nodes		  */
      tot_err += rfl * rfl;		/* error squared		  */

      delt[nl1][i2] = (rfl *= 1);	/* calculate gradient upto input  */
      pv1 = act[nl2];			/* output of previous layer	  */
      pv2 = &dw[pl[nl2] + i2 * sz[nl2]]; /* pointer gradient matrix       */
      pend = pv2 + sz[nl2];		/* pointer end of gradient matrix */
      for (; pv2 < pend;)		/* for all weights calculate      */
	(*pv2++) += rfl * (*pv1++);	/* derivative to that weight -var */
    }


    for (il = nl2; il > 1; il--) {	/* all layers upto input layer    */
      pv1 = delt[il];			/* point to start of delt matrix  */
      pend = pv1 + sz[il];		/* end of delt matrix / neuron	  */
      rfl = 0.000;			/* clear delt matrix 		  */
      for (; pv1 < pend;)		/* for all variables used	  */
	(*pv1++) = rfl;			/* initialie delt matrix          */

      for (i2 = 0; i2 < sz[il + 1]; i2++) { /* for all output units       */
	pv2 = &w[pl[il] + i2 * sz[il]];  /* pointer to weights used       */
	pend = pv2 + sz[il];		 /* pointer to end of weights     */
	pv1 = delt[il];			 /* pointer current delt matrix   */
	rfl = delt[il + 1][i2];		 /* pointer delt in upper layers  */
	for (; pv2 < pend;)		 /* summation over upper layer    */
	  (*pv1++) += (*pv2++) * rfl;	 /* times connection strength     */
      }

      for (i2 = 0; i2 < sz[il]; i2++) {  /* for all layer elements        */
	rfl = delt[il][i2] *= act[il][i2] * (1. - act[il][i2]);
	pv1 = act[il - 1];		 /* pointer output previous layer */
	pv2 = &dw[pl[il - 1] + i2 * sz[il - 1]];  /* gradient matrix      */
	pend = pv2 + sz[il - 1];	 /* end of gradient matrix        */
	for (; pv2 < pend;)		 /* for connection weights        */
	  (*pv2++) += rfl * (*pv1++);    /* derivative to varaibles       */
      }
    }

    pv1 = delt[1];			/* delt matrix for input layer    */
    pend = pv1 + sz[1];			/* end of matrix		  */
    rfl = 0.000;			/* intialize value = 0		  */
    for (; pv1 < pend;)			/* for all elemtent in matrix     */
      (*pv1++) = rfl;			/* clear matrix			  */

    for (i2 = 0; i2 < sz[2]; i2++) {    /* elements in next layer        */
      pv2 = &w[pl[1] + i2 * sz[1]];	/* pointer to weights used       */
      pend = pv2 + sz[1];		/* pointer end of weight matrix  */
      pv1 = delt[1];			/* delta matrix pointer		 */
      rfl = delt[2][i2];		/* upper layer delta martix      */
      for (; pv2 < pend;)		/* for all elements input layer  */
	 (*pv1++) += (*pv2++) * rfl;    /* summation over upper layer    */
    }

    for (i2 = 0; i2 < sz[1]; i2++) {    /* for all input elements        */
      rfl = delt[1][i2] *= act[1][i2] * (1. - act[1][i2]);
      pv1 = inact[iin];			/* inut action of network        */
      pv2 = &dw[sz[0] * i2];		/* pointer to gradient matrix    */
      pend = pv2 + sz[0];		/* end of gradient matrix	 */
      for (; pv2 < pend;)		/* for all weights of neuron     */
	(*pv2++) += rfl * (*pv1++);	/* derivative to specifiv var    */
    }
  }
  tot_err *= 0.5000;
  if (prt_flag)
    printf("%6.4f\n", tot_err);
  return tot_err;
}


main(argc, argv)
  int argc;
  char **argv;
{
  float ferr;				/* total error calculater so far */
  float ftemp;				/* temp floating operator	 */
  float tol;				/* fault tolerance of iteration  */
  float *w;				/* pointer to weight matrix	 */
  int   rnd;				/* random number seed value      */
  int   il,i1, i2, iin;			/* loop counter variables        */
  int   szmax;				/* maximum number of elements    */
  int   itemp;				/* temp integer operator	 */
  int   nconn;				/* total numner of connections   */
  int   cont_flag;			/* continue flag - learn process */
  int   nit;				/* number of current iteration   */
  FILE  *inp, *outp, *wp;		/* file pointer variables        */
  char  name[100];			/* file name varaible 		 */

  if ((argc != 4) && (argc != 5) && (argc != 6)) {
    printf("Usage:inputfile# continue_flag print_flag [seed] [nhid]\n");
    return;
  }

/*
 * continue_flag = 0 => random initially
 * otherwise         => read in initial weights
 * print_flag = 1    => report values of criterion function
 *
 */

  strcpy(name, CONST);			/* net architecture file	  */
  if (!(inp = fopen(strncat(name, argv[1], 2), "r")))
    eerror("const.file");

  cont_flag = atoi(argv[2]);		/* continue flag		  */
  prt_flag = atoi(argv[3]);		/* print flag - dos enviroment    */

  fscanf(inp, " %d %d %f %d", &nlayers, &nit, &tol, &rnd);
  if (nlayers < 3)
    eerror("Less than 3 layers");
  nl1 = nlayers - 1;			/* index of output layer    	  */
  nl2 = nlayers - 2;			/* index of last hidden layer     */

/*
 * Read in size of each layer; increment size of first layer for extra
 * neuron. Szmax set to size of largest layer
 *
 */

  if (!(sz = (int *) malloc(nlayers * sizeof(int))))
    eerror("sz");
  szmax = 0;
  for (il = 0; il < nlayers; il++) {
    fscanf(inp, " %d", &sz[il]);
    if (argc == 6) sz[1] = atoi(argv[5]);
    if (il == 0)
      sz[il]++;
    if (sz[il] > szmax)
      szmax = sz[il];
  }
  if (argc >= 5) rnd = atoi(argv[4]);

/***** Set pl[i] to the total number of weights up to layer i *****/
  if (!(pl = (int *) malloc(nl1 * sizeof(int))))
    eerror("pl");
  nconn = 0;
  for (il = 0; il < nl1; il++) {
    pl[il] = nconn;
    nconn += sz[il] * sz[il + 1];
  }


/*****    act    = matrix of neural activities			    ******/
/*****	  delt   = matrix of "delta" values		            ******/
/*****	  w      = weight matrix				    ******/
/*****	  inact  = matrix of input activities			    ******/
/*****	  outact = matric of output activities			    ******/
  if (!(act = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("act");
  if (!(delt = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("delt");
  if (!(w = (float *) malloc(nconn * sizeof(float))))
    eerror("w");

/**** Input activities; set inact[iin][ndim] equal to 1.00 ***/
  fclose(inp);
  strcpy(name, CLAS);
  if (!(inp = fopen(strncat(name, argv[1], 2), "r")))
    eerror("clasfile");
  fscanf(inp, "%d", &nin);
  if (!(inact = (float **) alloc2d(nin, sz[0], sizeof(float))))
    eerror("inact");
  if (!(outact = (float **) alloc2d(nin, sz[nl1], sizeof(float))))
    eerror("outact");

  for (iin = 0; iin < nin; iin++) {
    for (i1 = 0; i1 < sz[nl1]; i1++){
      if (fscanf(inp, "%f", &outact[iin][i1]) == EOF)
	eerror("Insufficient data");
    }
    for (i1 = 0; i1 < sz[0] - 1; i1++){
      if (fscanf(inp, "%f", &inact[iin][i1]) == EOF)
	eerror("Insufficient data");
      if ((inact[iin][i1]>MAXFEAT)||(inact[iin][i1]< -MAXFEAT))
	printf("WARNING: sample #%d has a large feature!\n",iin);
    }
    inact[iin][sz[0] - 1] = 1.0;
  }


/***** Initialize weights *****/
  if (cont_flag) {
    strcpy(name, OUTP);			/* name of class file		*/
    if (!(wp = fopen(strncat(name, argv[1], 2), "rt")))
      eerror("outfile");
    fscanf(wp, "%d", &itemp);		/* number of iterations in file */
    fscanf(wp, "%d", &nlayers);         /* read in number of layers     */
    for (i1=0; i1<nlayers; i1++)	/* read in net architecture     */
	fscanf(wp,"%d", &sz[i1]);
    fscanf(wp, "%d", &nconn);    	/* total number of connections  */
    for (i1=0; i1<nconn; i1++)
	fscanf(wp,"%f", &w[i1]);        /* read in weight matrix	*/
    fscanf(wp,"%f", &ferr);		/* error of objective funtion   */

    fclose(wp);				/* close input file		*/
  } else {
    srand(rnd);				/* initialize random number gen */
    for (il = 0; il < nl1; il++)	/* for all layers in network    */
      for (i1 = 0; i1 < sz[il]; i1++) { /* for all elements in layer    */
	ftemp = sz[il];			/* initialize weight matrix     */
	ftemp = sqrt((double) ftemp) / 3.;
	for (i2 = 0; i2 < sz[il + 1]; i2++)
	  w[pl[il] + i2 * sz[il] + i1] = (rand() / RMAX - 1.) / ftemp;
      }
  }


/**** Set up lookup table for exp-function ****/
  if (!(tab = (float *) malloc(TABSZ * sizeof(float))))
    eerror("tab");
  alpha = (float) TABSTEP;
  ftemp = TABSZ * TABSTEP / 2.;
  tabsz_2 = TABSZ / 2.;
  for (i1 = 0; i1 < TABSZ; i1++)
    tab[i1] = (float) 1. / (1 + exp(-(i1 * TABSTEP - ftemp)));


/**** optimize ****/
  ferr = cgrd(&w, nconn, nit, tol);

/** save weights **/
  strcpy(name, OUTP);			/* name of output file		*/
  if (!(outp = fopen(strncat(name, argv[1], 2), "wt")))
    eerror("outfile");

  fprintf(outp, "%d\n", nin);		/* save number of iterations    */
  fprintf(outp, "%d\n", nlayers);	/* number of layers in neural   */
  for (i1=0; i1<nlayers; i1++)
      fprintf(outp,"%d\n", *sz++);	/* save neural net architecture */
  fprintf(outp, "%d\n", nconn);		/* total number of connections  */
  for (i1=0; i1<nconn; i1++)
      fprintf(outp,"%f\n", *w++);	/* save all weight values	*/
  fprintf(outp,"%f\n", ferr);		/* total error of objective     */

  fclose(outp);				/* close output file		*/
}
