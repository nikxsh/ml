/*
 * OPTESTB.C
 *
 * Written by: Etienne Barnard
 * Adapted by: Johan Schalkwyk
 *
 * The OPTESTB program reruns the neural network in a purely
 * feedforward configuration. Each input vector is represented
 * to the network, and a corresponding output vector is calculated.
 *
 * The output vector with the correct output vector as supplied
 * by the input data file is then stored togeteher in a file. Thus
 * this program test the acurateness of the the neural net as
 * approximator.
 *
 *
 * Program Use:
 *
 *	OPTESTB data_set output_set
 *
 *	data_set: CLASB.DA(data_set) file that contains the data set
 *		  of the neural network under consideration.
 *	output_set: TESTB.DA(output_set) output file where test
 *		    information is written to.
 *
 *
 *  CLASB.DA(data_set) -- text file
 *
 *  line 1: number of training examples
 *  line 2.. : output vector + input vector
 *
 */


/* include file directives */
#include <include.h>

/* global constant definition */
#define RMAX 1.07374e+09
#define EMAX 20.0		/** cut-off for exp-function 		   **/
#define EMIN -20.0		/** cut-off for exp-function 		   **/
#define DATA "clasb.da"	/** data set file name		   **/
#define WT "optb.o"	/** neural architecture file name  **/
#define OUT "testb."      /** output file name		   **/

/* external function defintion */
extern char **alloc2d();
extern char ***alloc3d();

float	*w;				/* weight matrix pointer	*/
float 	**act;				/* neural net action matrix	*/
float 	**delt;				/* matrix gradient calculate	*/
float	**inact;			/* input activities of network  */
float 	**outact;			/* output activities of network */
int 	nlayers;			/* number of layers in network  */
int 	nin;				/* loop counter variable	*/
int 	nconn;				/* total number of connections  */
int 	*sz;				/* neural net architecture	*/
int 	nl1;				/* index of output layer        */
FILE 	*inp, *outp, *datp;		/* data file pointers		*/

/*
 * f(s)
 *
 * This funtion returns the sigmoid of the
 * input value receive
 *
 * s (in): input value of neuron
 *
 */

float f(s)
  float s;
{
  float x;

  x = s;
  if (x > EMAX)
    x = EMAX;
  else if (x < EMIN)
    x = EMIN;
  return (float) 1. / (1. + exp(-x));
}


/*
 * This function prints a message indicating
 * where in the program an error has occured.
 *
 */

void eerror(where)
  char *where;
{
  perror(where);
  exit(1);
}


/*
 * up_act(iin)
 *
 * Given the number of the training example up_act() does
 * feedforward process of the neural network, thus calculating
 * the network output of the current input vector, for comparison
 * with the true output vector
 *
 * iin (in): number of the training examples
 *
 */

void up_act(iin)
{
  int i1, i2, il, ct;			/* loop counter variable	*/
  float s;				/* floating point variable temp */

  register float rfl;			/* input activation of neuron   */
  register float *pv1, *pv2, *pend;	/* matrix pointer variables	*/

  pend = w;				/* point to start weight matrix */
  for (i2 = 0; i2 < sz[1]; i2++) {	/* for all elements in hidden   */
      rfl = 0.00;			/* layer, calculate		*/
      pv1 = pend;			/* output of first layer	*/
      pend = pv1 + sz[0];		/* end pointer of weight matrix */
      pv2 = inact[iin];			/* pointer to input actions	*/
      for (; pv1 < pend;)
	rfl += (*pv2++) * (*pv1++);	/* summation over all input's	*/

      act[1][i2] = f(rfl);		/* calculate output first layer */
    }

    for (il = 1; il < nl1; il++)	/* for all following layers	*/
      for (i2 = 0; i2 < sz[il + 1]; i2++) { /* for all current layer	*/
	rfl = 0.0;
	pv1 = pend;			/* current position of weight's */
	pend = pv1 + sz[il];		/* end pointer weight matrix	*/
	pv2 = act[il];			/* output actions previous layer */
	for (; pv1 < pend;)
	  rfl += (*pv1++) * (*pv2++);	/* summation over previous layer */
	if ((il+1)==nl1)
	  act[il+1][i2] = rfl;		/* output layer = linear	 */
	else
	  act[il + 1][i2] = f(rfl);	/* all other = sigmoid transfer  */
      }
}


main(argc, argv)
  int argc;
  char **argv;
{
  float temp;				/* temp floating point variable	*/
  float fmax;				/* maximum value		*/
  float fmin;				/* minimum value		*/
  float amax;				/*				*/
  float err;				/* error of objective function	*/
  int iin;				/* number of learning example   */
  int iit;				/* loop counter variable	*/
  int il, i, i1,i2, cl, j;		/* loop counter variable	*/
  int szmax;				/* maximu number of neurons	*/
  int finsz;				/* network size			*/
  int **confn;				/*				*/
  int cmax;				/*				*/
  int prt_flag=0;			/*				*/
  char name[100];			/* file name variable		*/

  if ((argc != 3) && (argc != 4)) {	/* print file usage on screen   */
    printf("Usage:inputfile# testfile# [print_flag]\n");
    return;
  }

  strcpy(name, WT);			/* weight matrix file name  	*/
  if (!(inp = fopen(strncat(name, argv[1], 2), "r")))
    eerror("infile");

  strcpy(name, OUT);			/* output file name		*/
  if (!(outp = fopen(strncat(name, argv[2], 2), "w")))
    eerror("outfile");

  strcpy(name, DATA);			/* input data file name		*/
  if (!(datp = fopen(strncat(name, argv[2], 2), "rt")))
    eerror("datfile");

  if (argc==4) prt_flag=atoi(argv[3]);

    fscanf(inp, "%d", &nin);		/* load number of iterations	*/
    fscanf(inp, "%d", &nlayers);	/* load number of layers in net */
    if (!(sz = (int *) malloc(nlayers * sizeof(int))))
       eerror("sz");

    for (i1=0; i1<nlayers; i1++)
	fscanf(inp,"%d", &sz[i1]);      /* load neural architecture   	*/
    fscanf(inp, "%d", &nconn);		/* load total number connections */
    if (!(w = (float *) malloc(nconn * sizeof(float))))
       eerror("w");

    for (i1=0; i1<nconn; i1++)
	fscanf(inp,"%f", &w[i1]);       /* load wegiht matrix in memory	*/
    fscanf(inp,"%f", &err);		/* load error of objective	*/

    nl1 = nlayers - 1;			/* index of output layer	*/
    szmax = 0;                          /* calculate maximum neurons	*/
    for (il = 0; il < nlayers; il++)
      if (sz[il] > szmax)
	 szmax = sz[il];
    fscanf(datp, "%d", &nin);		/* load number of examples	*/

/*****    act    = matrix of neural activities			    ******/
/*****	  delt   = matrix of "delta" values		            ******/
/*****	  w      = weight matrix				    ******/
/*****	  inact  = matrix of input activities			    ******/
/*****	  outact = matric of output activities			    ******/
  if (!(inact = (float **) alloc2d(nin, sz[0], sizeof(float))))
    eerror("inact");
  if (!(act = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("act");
  if (!(delt = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("delt");

  printf("err=%f\n", err);
  if (!(outact = (float **) alloc2d(nin, sz[nl1], sizeof(float))))
    eerror("outact");


/* load input / output actions of neural net */
  for (iin = 0; iin < nin; iin++) {
    for (i1 = 0; i1 < sz[nl1]; i1++){
      if (fscanf(datp, "%f", &outact[iin][i1]) == EOF)
	eerror("Insufficient data");
    }
    for (i1 = 0; i1 < sz[0] - 1; i1++)
      if (fscanf(datp, "%f", &inact[iin][i1]) == EOF)
	eerror("Insufficient data");
    inact[iin][sz[0] - 1] = 1.;
  }


/* calculate output activities of neural network */
  temp = 0.0;
  finsz = sz[nl1];
  for (iin = 0; iin < nin; iin++) {
    up_act(iin);
    for (i = 0; i < finsz; i++) {
      temp += (outact[iin][i] - act[nlayers-1][i])*(outact[iin][i] - act[nlayers-1][i]);
      if (prt_flag)
      printf("%7.4f -- %7.4f   ",outact[iin][i], act[nlayers - 1][i]);
      fprintf(outp,"%7.4f -- %7.4f   ",outact[iin][i], act[nlayers - 1][i]);
    }
    if (prt_flag)
    printf("\n");
    fprintf(outp,"\n");
  }
  printf("RMSE=%f\n", temp=sqrt(temp/nin));
  fprintf(outp,"RMSE=%f\n", temp);
  fclose(outp);				/* close output file		*/
  fclose(inp);				/* close input net file 	*/
  fclose(datp);				/* close input data file	*/

}
