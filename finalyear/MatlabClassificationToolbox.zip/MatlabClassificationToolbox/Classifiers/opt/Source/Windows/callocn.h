/* Include files */
#include <malloc.h>

#undef Extern
#ifndef Module
#define Extern
#else
#define Extern extern
#endif
Extern unsigned __ai;

#define calloc3(__w,__d1,__d2,__d3,__type,__msg) \
	__w  = (__type ***)calloc(__d1,sizeof(__type **));\
        calloc2(*__w,(__d1)*(__d2),(__d3),__type,__msg);\
        for(__ai=1; __ai < __d1; __ai++) (__w)[__ai] = (__w)[__ai-1] + (__d2)
#define calloc2(__w,__d1,__d2,__type,__msg) \
	__w  = (__type **)calloc((__d1),sizeof(__type *));\
	*__w = (__type *)calloc((__d1)*(__d2),sizeof(__type));\
	if(*__w == NULL) perror(__msg);\
	for(__ai = 1; __ai < (__d1); ++__ai)\
          (__w)[__ai] = (__w)[__ai-1] + (__d2)
#define calloc1(__w,__d1,__type,__msg) \
	__w  = (__type *)calloc((__d1),sizeof(__type));\
        if(__w == NULL) perror(__msg);
#define free2(__w)\
	free(*__w); free(__w)
#define free3(__w)\
	for(__ai=0; __ai < (__d1); __ai++) free2(__w[__ai]); free(__w)






