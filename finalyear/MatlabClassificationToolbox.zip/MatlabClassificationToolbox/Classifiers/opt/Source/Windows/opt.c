#include "include.h"
#include <stdlib.h>

/* Use the big value for RMAX on ix86 machines, and the small value for
	RISCs */
 /*#define RMAX  16383.5   /* (maximum random number)/2 **/
/* #define RMAX RAND_MAX */
#define RMAX 1.07374e+09 
#define TABSZ 50000		/** number of entries in sigmoid table **/
#define TABSTEP 0.0005		/** increment between entries in sigmoid table **/
#define OUT_HI 0.7		/** desired output - hi **/
#define OUT_M1 -0.3		/** (desired output - hi) - 1 **/
#define OUT_LOW 0.2		/** desired output - lo **/
#define EMAX 70.		/** cut-off for exp-function **/
#define EMIN -70.		/** cut-off for exp-function **/
#define CLAS "clas.da"		/** filename for test samples **/
#define CONST "opt.da"		/** filename for network parameters **/
#define OUTP "opt.o"		/** filename for output **/
#define MAXFEAT 100		/** if any input feature exceeds this, warn user **/

extern char **alloc2d();
extern float errfc(), cgrd();

float *w, **act, alpha, *tab, **delt, **inact, tabsz_2;
int nlayers, nin, *sz, *clas, nl1, nl2, *pl;
int prt_flag;

/****** Calculate sigmoid ******/
float
f(s)
  float s;
{
  float x;

  x = s / alpha;
  if (x > EMAX)
    x = EMAX;
  else if (x < EMIN)
    x = EMIN;
  return (float) 1. / (1. + exp(-(float) x));
}

/***** Exit with appropriate error message ******/
void
eerror(where)
  char *where;
{
  perror(where);
  exit(1);
}

/***** Calculate value of energy function at w; store gradient in dw *****/
float
errfc(w, dw, nconn)
  int nconn;			/** number of connections=dimensionality of w, dw **/
  float *w, *dw;
{
  int i2, il, ct, iin;
  float s, tot_err;
  register float rfl;
  register float *pv1, *pv2, *pend;

  /** clear dw **/
  rfl = 0.000;
  pv1 = dw;
  pend = pv1 + nconn;
  for (; pv1 < pend;)
    (*pv1++) = rfl;

  tot_err = 0.;
  for (iin = 0; iin < nin; iin++) {
    pend = w;
    for (i2 = 0; i2 < sz[1]; i2++) {
      rfl = 0.00;
      pv1 = pend;
      pend = pv1 + sz[0];
      pv2 = inact[iin];
      for (; pv1 < pend;)
	rfl += (*pv2++) * (*pv1++);

      ct = rfl / alpha + tabsz_2;
      if (ct >= TABSZ)
	ct = TABSZ - 1;
      else if (ct < 0)
	ct = 0;
      act[1][i2] = tab[ct];
    }
    for (il = 1; il < nl1; il++)
      for (i2 = 0; i2 < sz[il + 1]; i2++) {
	rfl = 0.;
	pv1 = pend;
	pend = pv1 + sz[il];
	pv2 = act[il];
	for (; pv1 < pend;)
	  rfl += (*pv1++) * (*pv2++);
	ct = rfl / alpha + tabsz_2;
	if (ct >= TABSZ)
	  ct = TABSZ - 1;
	else if (ct < 0)
	  ct = 0;
	act[il + 1][i2] = tab[ct];
      }
    for (i2 = 0; i2 < sz[nl1]; i2++) {
      if (i2 == clas[iin] - 1) {
	rfl = min(act[nl1][i2] - OUT_HI, 0);
      } else
	rfl = max(act[nl1][i2] - OUT_LOW, 0);
      tot_err += rfl * rfl;

      delt[nl1][i2] = (rfl *= act[nl1][i2] * (1. - act[nl1][i2]));
      pv1 = act[nl2];
      pv2 = &dw[pl[nl2] + i2 * sz[nl2]];
      pend = pv2 + sz[nl2];
      for (; pv2 < pend;)
	(*pv2++) += rfl * (*pv1++);

    }
    for (il = nl2; il > 1; il--) {
      pv1 = delt[il];
      pend = pv1 + sz[il];
      rfl = 0.000;
      for (; pv1 < pend;)
	(*pv1++) = rfl;
      for (i2 = 0; i2 < sz[il + 1]; i2++) {
	pv2 = &w[pl[il] + i2 * sz[il]];
	pend = pv2 + sz[il];
	pv1 = delt[il];
	rfl = delt[il + 1][i2];
	for (; pv2 < pend;)
	  (*pv1++) += (*pv2++) * rfl;
      }
      for (i2 = 0; i2 < sz[il]; i2++) {
	rfl = delt[il][i2] *= act[il][i2] * (1. - act[il][i2]);
	pv1 = act[il - 1];
	pv2 = &dw[pl[il - 1] + i2 * sz[il - 1]];
	pend = pv2 + sz[il - 1];
	for (; pv2 < pend;)
	  (*pv2++) += rfl * (*pv1++);
      }
    }
    pv1 = delt[1];
    pend = pv1 + sz[1];
    rfl = 0.000;
    for (; pv1 < pend;)
      (*pv1++) = rfl;
    for (i2 = 0; i2 < sz[2]; i2++) {
      pv2 = &w[pl[1] + i2 * sz[1]];
      pend = pv2 + sz[1];
      pv1 = delt[1];
      rfl = delt[2][i2];
      for (; pv2 < pend;)
	(*pv1++) += (*pv2++) * rfl;
    }
    for (i2 = 0; i2 < sz[1]; i2++) {
      rfl = delt[1][i2] *= act[1][i2] * (1. - act[1][i2]);
      pv1 = inact[iin];
      pv2 = &dw[sz[0] * i2];
      pend = pv2 + sz[0];
      for (; pv2 < pend;)
	(*pv2++) += rfl * (*pv1++);
    }
  }
  tot_err *= 0.5000;
  if (prt_flag)
    printf("%6.4f\n", tot_err);
  return tot_err;
}

main(argc, argv)
  int argc;
  char **argv;
{
  float ferr, ftemp, tol, *w;
  int rnd, il, i1, i2, szmax, iin, itemp, nconn, cont_flag, nit;
  FILE *inp, *outp, *wp;
  char name[100];

  if ((argc != 4) && (argc != 5) && (argc != 6)) {
    printf("Usage:inputfile# continue_flag print_flag [seed] [nhid]\n");
    return;
  }
  /***** continue_flag = 0 => random initially
		  otherwise  => read in initial weights
         print_flag = 1 => report values of criterion function
  ******/

  strcpy(name, CONST);
  if (!(inp = fopen((char *)strncat(name, argv[1], 2), "r")))
    eerror("const.file");

  cont_flag = atoi(argv[2]);
  prt_flag = atoi(argv[3]);

  fscanf(inp, " %d %d %f %d", &nlayers, &nit, &tol, &rnd);
  if (argc >= 5) rnd = atoi(argv[4]);

  if (nlayers < 3)
    eerror("Less than 3 layers");
  nl1 = nlayers - 1;
  nl2 = nlayers - 2;

  /***** Read in size of each layer; increment size of first layer for extra
      neuron. Szmax set to size of largest layer      ******/

  if (!(sz = (int *) malloc(nlayers * sizeof(int))))
    eerror("sz");
  szmax = 0;
  for (il = 0; il < nlayers; il++) {
    fscanf(inp, " %d", &sz[il]);
    if (argc == 6) sz[1] = atoi(argv[5]);
    if (il == 0)
      sz[il]++;
    if (sz[il] > szmax)
      szmax = sz[il];
  }

  /***** Set pl[i] to the total number of weights up to layer i *****/
  if (!(pl = (int *) malloc(nl1 * sizeof(int))))
    eerror("pl");
  nconn = 0;
  for (il = 0; il < nl1; il++) {
    pl[il] = nconn;
    nconn += sz[il] * sz[il + 1];
  }

  /*** act = matrix of neural activities
       delt = matrix of "delta" values - see PDP
       w = weight matrix
  ***/
  if (!(act = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("act");
  if (!(delt = (float **) alloc2d(nlayers, szmax, sizeof(float))))
    eerror("delt");
  if (!(w = (float *) malloc(nconn * sizeof(float))))
    eerror("w");

  /**** Input activities; set inact[iin][ndim] equal to 1.00 ***/
  fclose(inp);
  strcpy(name, CLAS);
  if (!(inp = fopen((char *)strncat(name, argv[1], 2), "r")))
    eerror("clasfile");
  fscanf(inp, "%d", &nin);
  if (!(clas = (int *) malloc(nin * sizeof(int))))
    eerror("clas");
  if (!(inact = (float **) alloc2d(nin, sz[0], sizeof(float))))
    eerror("inact");

  for (iin = 0; iin < nin; iin++) {
    fscanf(inp, "%d", &clas[iin]);
    if (clas[iin] > sz[nl1])
      eerror("More classes than output neurons");
    for (i1 = 0; i1 < sz[0] - 1; i1++){
      if (fscanf(inp, "%f", &inact[iin][i1]) == EOF)
	eerror("Insufficient data");
      if ((inact[iin][i1]>MAXFEAT)||(inact[iin][i1]< -MAXFEAT))
	printf("WARNING: sample #%d has a large feature!\n",iin);
    }
    inact[iin][sz[0] - 1] = 1.;
  }

  /***** Initialize weights *****/
  if (cont_flag) {
    strcpy(name, OUTP);
    if (!(wp = fopen((char *)strncat(name, argv[1], 2), "r")))
      eerror("outfile");
    fread(&itemp, sizeof(int), 1, wp);
    fread(&nlayers, sizeof(int), 1, wp);
    fread(sz, sizeof(int), nlayers, wp);
    fread(w, sizeof(float), nconn, wp);
    fread(&ferr, sizeof(float), 1, wp);
    fclose(wp);
  } else {
    srand(rnd);
    for (il = 0; il < nl1; il++){
      for (i1 = 0; i1 < sz[il]; i1++) {
	      ftemp = sz[il];
	      ftemp = sqrt((double) ftemp) / 3.;
	      for (i2 = 0; i2 < sz[il + 1]; i2++){
	          w[pl[il] + i2 * sz[il] + i1] = (rand() / RMAX - 1.) / ftemp;
           }
       }
    }
  }

  /**** Set up lookup table for exp-function ****/
  if (!(tab = (float *) malloc(TABSZ * sizeof(float))))
    eerror("tab");
  alpha = (float) TABSTEP;
  ftemp = TABSZ * TABSTEP / 2.;
  tabsz_2 = TABSZ / 2.;
  for (i1 = 0; i1 < TABSZ; i1++)
    tab[i1] = (float) 1. / (1 + exp(-(i1 * TABSTEP - ftemp)));

  /**** optimize ****/
  ferr = cgrd(&w, nconn, nit, tol);

  /** save weights **/
  strcpy(name, OUTP);
  if (!(outp = fopen((char *)strncat(name, argv[1], 2), "wb")))
    eerror("outfile");

  fwrite(&nit, sizeof(int), 1, outp); 
  fwrite(&nlayers, sizeof(int), 1, outp);
  fwrite(sz, sizeof(int), nlayers, outp);
  fwrite(w, sizeof(float), nconn, outp);
  fwrite(&ferr, sizeof(float), 1, outp);

}
