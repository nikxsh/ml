#ifdef MAIN
#undef Module
#else
#define Module
#endif

#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include "callocn.h"

#define max(a,b)	((a)<(b)?(b):(a))
#define min(a,b)	((a)<(b)?(a):(b))
#define eerror(a)	{perror(a); exit(-1);}

float cgrd(float **x, int nconn, int nit, float tol);
float f(float s);
float errfc(float *w, float *dw, int nconn);

