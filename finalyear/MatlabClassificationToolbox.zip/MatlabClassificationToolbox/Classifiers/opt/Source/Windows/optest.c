#define MAIN
#include "opt.h"

#define EMAX 50
#define EMIN -50
#define DATA "clas.da"
#define WT "opt.o"
#define OUT "test."
#define OUTWHO "who."

float ***w, **act, **delt, **inact;
int nlayers, nin, *sz, *clas;
FILE *inp, *outp, *outwhop, *datp;

float f(float s)
{
  float x;

  x = s;
  if (x > EMAX)
    x = EMAX;
  else if (x < EMIN)
    x = EMIN;
  return (float) 1. / (1. + exp(-x));
}

/** Calculate output of net for input # iin **/
void up_act(int iin)
{
  int i1, i2, il, ct;
  float s;
  
  for (i2 = 0; i2 < sz[1]; i2++) {
    s = 0.;
    for (i1 = 0; i1 < sz[0]; i1++)
      s += w[0][i2][i1] * inact[iin][i1];
    act[1][i2] = f(s);

  }
  for (il = 1; il < nlayers - 1; il++)
    for (i2 = 0; i2 < sz[il + 1]; i2++) {
      s = 0.;
      for (i1 = 0; i1 < sz[il]; i1++)
	s += w[il][i2][i1] * act[il][i1];
      act[il + 1][i2] = f(s);
    }
}

main(int argc, char **argv)
{
  float temp, fmax, fmin, amax, err;
  int iin, iit, il, i, i1, i2, szmax, finsz, cl, **confn, cmax, j, nl1;
  char name[100];

  if (argc != 3) {
    printf("Usage:inputfile# testfile#\n");
    return;
  }
  strcpy(name, WT);
  if (!(inp = fopen((char *)strncat(name, argv[1], 4), "rb")))
    eerror("infile");

  strcpy(name, OUT);
  if (!(outp = fopen((char *)strncat(name, argv[2], 4), "w")))
    eerror("outfile");

  strcpy(name, OUTWHO);
  if (!(outwhop = fopen((char *)strncat(name, argv[2], 4), "w")))
    eerror("outwhofile");

  strcpy(name, DATA);
  if (!(datp = fopen(strncat((char *)name, argv[2], 4), "r")))
    eerror("datfile");

  fread(&iit, sizeof(int), 1, inp);

  fread(&nlayers, sizeof(int), 1, inp);

  calloc1(sz, nlayers, int, "sz");
  fread(sz, sizeof(int), nlayers, inp);
  nl1 = nlayers - 1;

  szmax = 0;
  for (il = 0; il < nlayers; il++)
    if (sz[il] > szmax)
      szmax = sz[il];
  fscanf(datp, " %d", &nin);
  /** confn contains confusion matrix; for other definitions see opt.c **/
  calloc2(confn, sz[nl1], sz[nl1], int, "confn");
  calloc1(clas, nin, int, "clas");
  calloc2(inact, nin, sz[0], float, "inact");
  calloc2(act, nlayers, szmax, float, "act");
  calloc2(delt, nlayers, szmax, float, "delt");
  calloc3(w, nl1, szmax, szmax, float, "w");
  
  printf("\n");
  for (il = 0; il < nl1; il++)
    for (i1 = 0; i1 < sz[il + 1]; i1++){
      fread(w[il][i1], sizeof(float), sz[il], inp);
    }

  fread(&err, sizeof(float), 1, inp);
  printf("err=%f\n", err);

  for (iin = 0; iin < nin; iin++) {
    fscanf(datp, "%d", &clas[iin]);
    if (clas[iin] > sz[nl1])
      eerror("More classes than output neurons");
    for (i1 = 0; i1 < sz[0] - 1; i1++)
      if (fscanf(datp, "%f", &inact[iin][i1]) == EOF)
	eerror("Insufficient data");
    inact[iin][sz[0] - 1] = 1.;
  }

  finsz = sz[nl1];
  for (iin = 0; iin < nin; iin++) {
    up_act(iin);
    cl = clas[iin] - 1;
    /** find most active output neuron **/
    amax = act[nlayers - 1][0];
    cmax = 0;
    for (i = 1; i < finsz; i++)
      if (act[nlayers - 1][i] > amax) {
	amax = act[nlayers - 1][i];
	cmax = i;
      }
    /** increment appropriate counter in confusion matrix **/
    confn[cl][cmax]++;
    /** if incorrect classification, log it in outwho **/
    if(cl != cmax)
      fprintf(outwhop,"Sample #%d of class %d classified as %d\n",iin+1,cl+1,
	      cmax+1);
  }
  /** compute total # correctly classified **/
  amax = 0;
  for (i = 0; i < finsz; i++)
    amax += confn[i][i];

  printf("%% correct= %5.2f\n", 100. * amax / nin);
  fprintf(outp, " # of its.: %d; %% correct= %5.2f\n", iit, 100. * amax / nin);

  fprintf(outp, "label");
  for (i = 0; i < finsz; i++)
    fprintf(outp, " %4i", i + 1);
  fprintf(outp, "\n");
  fprintf(outp, "-----");
  for (i = 0; i < finsz; i++)
    fprintf(outp, " ----");
  fprintf(outp, "\n");
  for (i = 0; i < finsz; i++) {
    fprintf(outp, "%4i:", i + 1);
    for (j = 0; j < finsz; j++)
      fprintf(outp, " %4d", confn[i][j]);
    fprintf(outp, "\n");
  }

}
