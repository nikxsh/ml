%Use runopt.m to run this script
function acc_hn = opttr(data,n,d,p_flag,c_flag,hidnmin,hninc,hidnm,folds,nolayers,noiterations,trtolerance,seedv)
this_dir = pwd;

%Determine the number of classes
if min(data(:,end))==0
    C = max(data(:,end))+1;
elseif min(data(:,end))==1
    C = max(data(:,end));
end%if

%Normalise the data
norm=max(abs(data(:,1:d)));

%if the maximum abs value of an attribute is zero,
%don't normalize the attribute
for itrt=1:d
    if norm(itrt) == 0
        norm(itrt) = 1; 
    end
end%for

for nitr=1:n
    ndata(nitr,1:d) = data(nitr,1:d)./norm;
end%for

%Switch the class column vector
ndatat = data(:,end)+1;%Class labels must be from 1,..,C
ndatat(:,2:d+1) = ndata(:,1:d);
ndata = ndatat;

for hidn=hidnmin:hninc:hidnm
accr  = zeros(1,10); 
%Split the data into folds
%find the indices of the classes
for idxitr=1:C
    idxs{idxitr} = find(ndata(:,1)==idxitr);
end%for
%find out how many the test/validation observations are 
%required from each class
for idxitr=1:C
    csize(idxitr) = length(idxs{idxitr})./10;
end%for

for critr=1:10%cross-validation
%extract one of 10 folds of the data
tempd = [];
for clitr=1:C
    t_tidx = idxs{clitr};%the indices of all samples of this class
    tidx = t_tidx(floor(csize(clitr)*(critr-1)+1):floor(critr*csize(clitr)));%the indices of the test samples to be used of this class
    %tidx = t_tidx(csize(clitr)*(critr-1)+1:critr*csize(clitr));%the indices of the test samples to be used of this class
    tempd = [tempd; ndata(tidx,:)];
end%for te
fold{critr} = tempd;
end%for critr


for cvn=1:10
ds = ones(1,10);%flags to mark training folds
ds(cvn) = 0;%0 is the testing fold
te_idx = cvn;
tr_idx = find(ds == 1);

ndata_tr = [];
for fitr=1:9
    ndata_tr = [ndata_tr; fold{tr_idx(fitr)}]; 
end

ndata_te = fold{te_idx};

%save
%extract the training data
%ndata_tr = [];
%for clitr=1:C
%    t_tidx = idxs{clitr};%the indices of all samples of this class
%    tidx = t_tidx(csize(clitr)+1:end);%the indices of the training samples to be used of this class
%    ndata_tr = [ndata_tr; ndata(tidx,:)];
%end%for tr

    
%Create the configuration file
%Config : 3 1000 0.001 12321 4 3 3
%Write configuration files for the training sets

inpn = d;%nodes in input layer
outn = C;%nodes in the output layer 

for M=1:2%training and testing set
%Configuration file
filename = sprintf('opt.da%g',M+(cvn-1)*2);
fid = fopen(filename,'w');
fprintf(fid,'%g %g %g %g %g %g %g\n',nolayers, noiterations,trtolerance,seedv,inpn,hidn,outn);
fclose(fid);

%Create the training sets (clas.daN)
%It reads the training samples from the file clas.daN (N the same set
%number), and writes the trained network to the file opt.oN. 

%generate data files
dat = [];
if M ==1 
    dat = ndata_tr;
    n2 = size(ndata_tr,1);
elseif M == 2
    dat = ndata_te;
    n2 = size(ndata_te,1);
end%if

filename = sprintf('clas.da%g',M+(cvn-1)*2);
fid = fopen(filename,'w');
fprintf(fid,'%g\n',n2);
fclose(fid);

fid = fopen(filename,'a');

for itr=1:n2
    for i=1:d+1
        fprintf(fid,'%g ',dat(itr,i));
    end
    fprintf(fid,'\n');
end
fclose(fid);
end%for M

%Call opt.exe
%%opt trains a feedforward neural network, using a configuration contained
%in the file opt.daN, where N is the set number specified.
%opt creates a network N=M
%param 1 - set number
%param 2 - continue flag
%param 3 - print flag
M=1;%train on set number M (1,3,5,7,...,19)
%test on sets (2,4,6,...,20)
callstr = sprintf('opt %g %g %g',M+(cvn-1)*2,c_flag,p_flag);
%fprintf('Training NN\n');
%spstr=sprintf('SET PATH="%s\\Classifiers\\Opt";',this_dir)
%dos(spstr)
[s,w]=dos(callstr);

%Test the NN on the training data
%Test data set M on neural network N
%N = 1;%use network trained on M=N=1
N = M+(cvn-1)*2; 
M = 2;%test on data set 2
callstr = sprintf('optest %g %g',N,M+(cvn-1)*2);
%or
%callstr = sprintf('optest %g %g',N,N+1);
%fprintf('Testing NN\n');
[s,w]=dos(callstr);
%[s,w]=dos(sprintf('"%s/%s"',this_dir,callstr))%call opt.exe

%extract the accuracy from the output w
indx = max(find(w == '='));
accr(1,cvn) = str2num(w(indx+1:length(w)));
%fprintf('Hid Nodes = %g (cvn = %g): %s',hidn,cvn,acc(cvn));

end%cvn
acc_hn(hidn) = sum(accr)/10;%average cross validation accuracy
%acc_hn
fprintf('Hid Nodes = %g : %g\n',hidn,acc_hn(hidn));
%accr
end%for hidn





	