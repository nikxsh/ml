%Perform 10-fold cross-validation with opt
clear
close all
clc

%Stopping criteria - if error rate remains the same 2 epochs or if
%the error rate drops

%Determine the optimal no of hidden nodes
p_flag = 0;%print
c_flag = 0;%continue - to continue, you must mave the number of
hidnmin = 1;%minimum number of hidden nodes
hidnm = 10;%maximum number of hidden nodes

%Load the data
dsn = 'iris.mat';
load(dsn);
fprintf('%s\n',dsn);
n = size(data,1);%number of obsevations
d = size(data,2)-1;%dimensionality of data
folds = 10;

%Network parameters
nolayers = 3;
noiterations = 900000;%max no of iterations
trtolerance = 1e-25;%training tolerance
seedv = 12321;
%seedv = floor(rand*100000);

%Train and test the NN with different number of hidden nodes
acc_hn = opttr(data,n,d,p_flag,c_flag,hidnmin,hidnm,folds,nolayers,noiterations,trtolerance,seedv);%run the cross-validation opt script

[optv opt_hn] = max(acc_hn);%the optimal number of hidden nodes for this specific data set
cont_f = 1;%continue to train on this optimal number

hidnmin = opt_hn;
hidnm = opt_hn;
c_flag = 0;%train the NN from scratch on the optimal number of hidden nodes
acc_hn = opttr(data,n,d,p_flag,c_flag,hidnmin,hidnm,folds,nolayers,noiterations,trtolerance,seedv);%run the cross-validation opt script
opt_acc = acc_hn(hidnmin);%the accuracy after 1 training session

same = 0;%count how many times the accuracy remained the same
%Continue training
while cont_f == 1
   c_flag = 1;%continue training on the optimal NN
   acc_hn = opttr(data,n,d,p_flag,c_flag,hidnmin,hidnm,folds,nolayers,noiterations,trtolerance,seedv);%run the cross-validation opt script   
   new_acc = acc_hn(hidnmin);%new accuracy after the training session
   if new_acc > opt_acc
        opt_acc = new_acc;
        cont_f = 1;%keep on training
   elseif new_acc == opt_acc
        same = same + 1;
        cont_f = 1;%keep on training
   elseif new_acc < opt_acc
        cont_f = 0;%stop training
   end
   %Stopping criteria (if accuracy of NN remained the same 2 times)
   if same == 2
        cont_f = 0;
   end
end%while
fprintf('Seed Value = %g\n',seedv);