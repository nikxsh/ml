function scatter3D(datao, fs, tstr,xstr,ystr)
%3 Dimensional Scatter Plot of Data
if min(datao(:,end)) == 0
    C = max(datao(:,end))+1;
    datao(:,end) = datao(:,end)+1;
else
    C = max(datao(:,end));    
end

figure;
clrs = ['r','g','b','k','c'];
for citr=1:C
    datac = getcldat(datao, citr);
    scatter3(datac(:,fs(1)), datac(:,fs(2)), datac(:,fs(3)),10, clrs(citr),'filled');
    hold on;
end
title(sprintf('%s',tstr));
xlabel(xstr);
ylabel(ystr);
