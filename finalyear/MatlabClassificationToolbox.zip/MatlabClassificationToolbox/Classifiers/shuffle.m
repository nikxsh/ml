function sdata = shuffle(data)
%Shuffles a data set

N = size(data,1);
shufm = 1:N;
%shuffle the indexes in shufm
for itr=N:-1:1
    v = ceil(rand()*itr);
    sdata(itr,:)=data(shufm(v),:);
    shufm(v)=[];%remove the observation after its has been selected   
end

