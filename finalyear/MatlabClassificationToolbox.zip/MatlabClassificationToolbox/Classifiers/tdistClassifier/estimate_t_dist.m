function [mean, sigma, deg] = estimate_t_dist(data_set)
%Constants
NUM_EM_ITERATIONS = 50;

% Calculate argument dimensions
dim = length(data_set(:,1));
num_samples = length(data_set(1,:));

% Calculate sample mean
%sample_mean = zeros(dim,1);
%for i = 1:num_samples 
%	sample_mean = sample_mean + data_set(:,i);
%end
%sample_mean = sample_mean / num_samples;
%sample_mean = 0;

for (i = 1:dim)
	[values, index] = sort(data_set(i,:), 'ascend');
	median(i,1) = values(round(num_samples/2));
end
sample_mean = median;


%Cut of all the heavy tails for covariance direction estimation
tail_percentage_cutoff = 0;


data_set_abs = zeros(1, num_samples);
for (i = 1:num_samples)
	data_set_abs(1, i) = (data_set(:,i) - sample_mean)'*(data_set(:,i) - sample_mean);
end
data_set_abs;

[sorted_mag_data, index] = sort(data_set_abs, 'ascend');
mag_threshold = sorted_mag_data((1 - tail_percentage_cutoff/100)*num_samples);
%mag_threshold

num_tailless_samples = 0;

for (i = 1:num_samples)
	if (data_set_abs(1,i) <= mag_threshold)
		num_tailless_samples = num_tailless_samples + 1;
		data_set_clip(:,num_tailless_samples) = data_set(:,i);	
	end
end
%data_set_clip

num_tailless_samples;

% Calculate normalized covariance matrix
M = zeros(dim, num_tailless_samples);
for i = 1:num_tailless_samples
	M(:,i) = sample_mean;
end
org_sigma = (data_set_clip - M)*((data_set_clip - M)')/(num_tailless_samples - 1);
sigma_det = det(org_sigma);
norm_sigma = org_sigma * (sigma_det^(-1/dim));
norm_sigma_inv = inv(norm_sigma);

%Estimate sigma_sqr and v using EM algorithm
sigma_sqr = 1;
v = 50;

for (t = 1:NUM_EM_ITERATIONS)
	
	sigma_sum = 0;
	v_sum = 0;
	
	for (j = 1:num_samples)
		delta = data_set(:,j) - sample_mean;
		sj = delta'*norm_sigma_inv*delta;

		expectation = sigma_sqr*(v + dim)/(v*sigma_sqr + sj);

		sigma_sum = sigma_sum + expectation*sj;
		v_sum = v_sum + sj;
	end

	sigma_sqr = sigma_sum/(num_samples*dim);
	v = 2/(1 - (dim)*(num_samples-1)*sigma_sqr/(v_sum));
end

%end

% Final return values
mean = sample_mean;
sigma = sigma_sqr*norm_sigma;
deg = v;