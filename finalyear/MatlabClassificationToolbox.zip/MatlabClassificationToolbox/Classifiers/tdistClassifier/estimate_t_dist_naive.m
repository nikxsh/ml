function [mean, sigma, deg] = estimate_t_dist_naive(data_set)

% Calculate argument dimensions
dim = length(data_set(:,1));
num_samples = length(data_set(1,:));

% Calculate sample mean
%sample_mean = zeros(dim,1);
%for i = 1:num_samples 
%	sample_mean = sample_mean + data_set(:,i);
%end
%sample_mean = sample_mean / num_samples;
%sample_mean = 0;

for (i = 1:dim)
	[values, index] = sort(data_set(i,:), 'ascend');
	median(i,1) = values(round(num_samples/2));
end
sample_mean = median;


%Cut of all the heavy tails for covariance direction estimation
tail_percentage_cutoff = 0;


data_set_abs = zeros(1, num_samples);
for (i = 1:num_samples)
	data_set_abs(1, i) = (data_set(:,i) - sample_mean)'*(data_set(:,i) - sample_mean);
end
data_set_abs;

[sorted_mag_data, index] = sort(data_set_abs, 'ascend');
mag_threshold = sorted_mag_data(floor((1 - tail_percentage_cutoff/100)*num_samples));

num_tailless_samples = 0;

for (i = 1:num_samples)
	if (data_set_abs(1,i) <= mag_threshold)
		num_tailless_samples = num_tailless_samples + 1;
		data_set_clip(:,num_tailless_samples) = data_set(:,i);	
	end
end
data_set_clip;

num_tailless_samples;

% Calculate covariance matrix
M = zeros(dim, num_tailless_samples);
for i = 1:num_tailless_samples
	M(:,i) = sample_mean;
end
org_sigma = (data_set_clip - M)*((data_set_clip - M)')/(num_tailless_samples - 1);

%Get normalized eigen_vectors
try
    [V1, L1] = eig(org_sigma);
catch    
    V1 =eye(dim,dim);
end

%Transform all data into new eigenvector directions
M = zeros(dim, num_samples);
for i = 1:num_samples
	M(:,i) = sample_mean;
end

data_set_nomean_uncorr = V1'*(data_set - M);

avg_degree = 0;
uncorr_sigma = zeros(dim, dim);
for (d = 1:dim)
	[mean_1d, sigma_1d, deg_1d] = estimate_t_dist(data_set_nomean_uncorr(d,:));
	avg_degree = avg_degree + deg_1d;
	uncorr_sigma(d, d) = sigma_1d;
end


deg_final = avg_degree / dim;

sigma_final = V1*uncorr_sigma*V1';

if (deg_final < 2.2)
	deg_final = deg_final / 2;
	sigma_final = sigma_final / 2;
end

mean_final = sample_mean;

mean = mean_final;
sigma = sigma_final;
deg = deg_final;


