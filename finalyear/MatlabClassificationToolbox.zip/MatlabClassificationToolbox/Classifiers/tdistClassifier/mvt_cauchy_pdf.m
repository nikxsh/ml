function prob = mvt_dist_naive(x, mean, cov, deg)

dim = length(x(:,1)); 
x = x - mean;

prob = gamma((deg + 1)/2) / ((pi*deg)^(1/2)*gamma(deg/2)) * (1 + (x'*x)/deg)^(-(deg+1)/2);
