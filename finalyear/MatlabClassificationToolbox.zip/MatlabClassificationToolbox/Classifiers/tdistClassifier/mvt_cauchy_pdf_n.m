function prob = mvt_cauchy_pdf_n(x, mean, cov, deg)
%Naive t-distribution pdf

dim = length(x(:,1)); 
x = x - mean;

prob = 1;
for i=1:dim
    prob = prob * gamma((deg + 1)/2) / ((pi*deg)^(1/2)*gamma(deg/2)) * (1 + (x(i,1)'*x(i,1))/deg)^(-(deg+1)/2);
end
