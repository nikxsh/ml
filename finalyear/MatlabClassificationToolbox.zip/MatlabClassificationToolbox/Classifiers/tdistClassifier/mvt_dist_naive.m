function prob = mvt_dist_naive(x, mean, cov, deg)
%Semi-Naive t-dsitribution pdf
dim = length(x(:,1)); 

try%semi-naive
    [V, L] = eig(cov);
    x_uncorr = V'*(x - mean);

    prob = 1;
    for i = 1:dim
        prob = prob * gamma((deg + 1)/2)/((pi*deg)^(1/2)*(L(i,i))^(1/2)*gamma(deg/2))*(1 + x_uncorr(i,1)*x_uncorr(i,1)/(L(i,i)*deg))^(-(deg+1)/2);
    end 
catch%naive    
     prob = mvt_cauchy_pdf_n(x, mean, cov, deg);
end
