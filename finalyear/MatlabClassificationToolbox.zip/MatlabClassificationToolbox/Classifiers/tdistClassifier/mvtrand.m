function sample = mvtrand(mean, A_matrix, alpha) 

dim = length(mean(:,1));

for (j = 1:dim)
	x(j,1) = randt(alpha);
end

y = A_matrix*x + mean;

sample = y;
