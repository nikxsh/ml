function [rand_t_num] = randt(alpha)

sample = 0;
sample_found = 0;

while (sample_found == 0)
	u = rand;

	if (u >= 0.5)
		x = 4*u - 3;
		v = rand;
	else
		if (u == 0.25)
			x = 1E99;
		else
			x = 0.25/(u - 0.25);
		end
		u1 = rand;
		v = u1/(x*x);
	end

	if (v < 1 - abs(x)/2)
		sample_found = 1;
		sample = x;
	else
		u_alpha = (1 + (x^2)/alpha)^(-(alpha + 1)/2);
		if (v < u_alpha)
			sample_found = 1;
			sample = x;
		end
	end

	
end

rand_t_num = sample;




