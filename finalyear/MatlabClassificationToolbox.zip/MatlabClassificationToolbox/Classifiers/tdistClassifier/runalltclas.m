clear all
close all
clc

%dsnames = {'iris.txt', 'artificial1.txt', 'artificial2.txt', 'splice.txt','ionosphere.txt'};
dsnames = {'splice.txt','ionosphere.txt'};

for dsitr=1:length(dsnames)
    fprintf('%s\n',dsnames{dsitr});
    [tc_err tc_errs] = tdistclassifier(dsnames{dsitr});
    fprintf('t-dist(full)   err = %g\n',tc_err);
    
    [tsnc_err tsnc_errs] = tdistclassifier_snaive(dsnames{dsitr});
    fprintf('t-dist(snaive) err = %g\n',tsnc_err);
    
    [tnc_err tnc_errs] = tdistclassifier_naive(dsnames{dsitr});    
    fprintf('t-dist(naive)  err = %g\n',tnc_err);    
end


