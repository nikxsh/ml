clear all
close all
clc

dsnames = {'iris.txt', 'artificial1.txt', 'artificial2.txt', 'splice.txt','ionosphere.txt'};
%dsnames = {'ionosphere.txt'};

%Test t-dist classifiers on training data
for dsitr=1:length(dsnames)
    fprintf('%s\n',dsnames{dsitr});
    tc_err = tdistclassifier_tr(dsnames{dsitr});
    fprintf('t-dist(full)   err = %g\n',tc_err);
    tsnc_err = tdistclassifier_snaive_tr(dsnames{dsitr});
    fprintf('t-dist(snaive) err = %g\n',tsnc_err);
    tnc_err = tdistclassifier_naive_tr(dsnames{dsitr});
    fprintf('t-dist(naive)  err = %g\n',tnc_err);         
end


