%Implementation of a Naive Cauchy Classifier
function [err errs] = cauchyclassifier_naive(dsname)
%clear all
%close all

%load the data
%data = load('artificial1.txt');
data = load(dsname);

[N col] = size(data);
d = col-1;

if min(data(:,end))==0
    data(:,end)=data(:,end)+1;
    C = max(data(:,end));
else
    C = max(data(:,end));
end

%Perform 10-fold cross-validation
for cvn=1:10
cvalid
getcvfold
%estimate the parameters of a t distribution for each class
for citr=1:C
    clidx{citr} = find(data_tr(:,end)==citr);
    cldata{citr} = data_tr(clidx{citr},:);
    tmp = [];
    tmp = cldata{citr};
    dat = [];
    dat = tmp(:,1:d)';
    [mean{citr} sigma{citr} deg(citr)] = estimate_t_dist_naive(dat);
end%for citr

%Test on training data
prob = [];
predxl = [];
for nitr=1:size(data_te,1)
    x = data_te(nitr,1:d)';%observation to classify
    for citr=1:C
        prob(nitr,citr)=mvt_cauchy_pdf_n(x,mean{citr},sigma{citr},deg(citr));
    end
    [mv predxl(nitr)] = max(prob(nitr,:));%determine class label for x
end

%Calculate accuracy
dif = predxl' - data_te(:,end);
correct = length(find(dif == 0));
acc = correct/length(dif)*100;
errs(cvn) = (100 - acc)/100;
end%for cvn
err = sum(errs)/10;

