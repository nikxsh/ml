%MATLAB CLASSIFICATION TOOLBOX

%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%Licence
%This code is published under the GNU Public licence

%Contents of this toolbox (see scripts for synopsis of functions):
%Data measures
%statistical_measures_all(verb)
%information_measures_all(verb)

%Classifiers 
%nnclassifierf.m - Neural Network
%optclassifier.m - Neural Network written by Etienne Barnard (must compile source for linux)
%nbclassifierf.m - Naive Bayes Classifier
%lgclassifierf.m - Linear Gaussian Classifier
%ldclassifierf.m - Linear Discriminant Classifier
%knnclassifierf.m - k-Nearest-Neighbour Classifier
%GMMclassifierf.m - Gaussian Mixture Model Classifier
%gaussianclassifierf.m - Gaussian Classifier
%DTclassifierf.m - Decision Tree Classifier
%tdistclassifier.m - t-distribution classifier
%tdistclassifier_naive.m - t-distribution classifier
%tdistclassifier_snaive.m - t-distribution classifier

%Clustering
%kmeans_script.m - kMeans Clustering

%Real-world data sets (from UCI ML Repository)
%See the Datasets folder

%Examples
%example.m - classifies the iris data sets with all the classifiers
