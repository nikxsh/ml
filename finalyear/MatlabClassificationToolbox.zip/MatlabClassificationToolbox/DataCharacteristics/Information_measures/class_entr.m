%Coverts any continous dataset to a discrete dataset
%each variable has nosteps different values it can take on
%Calculates prior prob of each discrete value
%Calculates entropy of each possible value
%Finally calculates the entropy of the entire dataset (avg of variable
%entropy's)

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

temp = datain; %save the original datain matrix
datain = dataout;%copy the class values as input

mindatain = min(datain);
maxdatain = max(datain);
ranges = maxdatain - mindatain;
%make 10 dicrete values for each continous variable
%step size
steps = ranges/nosteps;

%make all values discrete, 10 discrete values for each variable
for i=1:size(datain,1)    
    for j=1:size(datain,2)
        for count=1:nosteps
            diffs(count) = datain(i,j) - mindatain(j) - (count-1)*(steps(j));
        end
        diffs = abs(diffs);
        [minv, winner] = min(diffs);
        %newval = mindatain(j) + (winner-1)*steps(j);
        newval = mindatain(j) + (winner-1)*steps(j);
        if(i == size(datain,1))
            newval = mindatain(j) + (winner-1)*steps(j);
        end
        discrdatain(i,j) = newval;
    end
end

%make a matrix that contains all possible values for each variable
for i=1:nosteps    
    for j=1:size(datain,2)
        indexval(i,j) = mindatain(j) + (i-1)*(steps(j)); 
    end
end

%calculate the prior prob of each possible value
%the prob corresponds to the values in indexval
probval = zeros(size(datain,1),size(datain,2));  

for i=1:nosteps  
    for j=1:size(datain,2)
        probval(i,j) = length(find(discrdatain(:,j) == indexval(i,j)))/size(datain, 1);
    
    end
end

%NB!
%Discrete variables have been resampled to nostep different variables.
%This however does not influence the results,
%if you look at matrix p, you will see the discrete values
%that are created additionally is not used.

%calculate the entopy of each variable
%each column represents a variable
H = entropy(probval, 0);

%calculate the entropy of the entire dataset
classent = sum(H)/length(H);

if verb == 1
fprintf(fid,'The entropy of the classes, H(C):\n');
fprintf(fid,'%g\n',classent);
fprintf(fid,'\n');
save('avg_class_entropy.txt','-ascii','classent');
end

datain = temp;%restore the original datain

%copy the probability matrix for use in cross_entropy.m
q = probval;
