function information_measures(datn, fid, verb)
%Calculates the information theoretic measures of a data set
%See the Statlog Project, Michie, 1994 for more information

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

datasetn = cast(datn,'char');
fprintf(fid,'Information theoretic measures for: %s dataset\n\n',datasetn);
%pathn = sprintf('Datasets\\%s\\%s.mat',datasetn,datasetn);
data = load(strcat(datn,'.txt'));
discl = 10;%number of discrete levels

obsn = size(data, 1); %number of rows
attrn = size(data, 2)-1;%determine the number of attributes (the last column is the class)
no_classes = max(data(:,attrn+1))+1;
datain = data(:,1:attrn);
dataout = data(:,attrn+1);

fprintf(fid,'N (number of observations): %g\n',obsn);
fprintf(fid,'p (number of attributes)  : %g\n',attrn);
fprintf(fid,'k (number of classes)     : %g\n',no_classes);  
fprintf(fid,'d (discrete levels)       : %g\n\n',discl);

%Calculates the entropy of the dataset (all the attributes)
attr_entr;
%Calculates the entropy of the class
class_entr;
%Calculates the joint entropy of the class and attribute
joint_entr;

%Calculates all the information measures, using the 
%mutual information between the class variable
%and the dataset variables
mutual;
