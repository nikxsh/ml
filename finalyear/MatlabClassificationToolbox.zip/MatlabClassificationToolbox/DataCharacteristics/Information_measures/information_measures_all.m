function information_measures_all(verb)
%Calculates the information theoretic measures of a data set
%See the Statlog Project, Michie, 1994 for more information

%Usage: 
%information_measures_all(0) % verbose of
%information_measures_all(1) % verbose on

%verb - verbose mode, if verb == 1 then write all the stats
%to seperate txt files

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

clc
%Include all the data set names to be analysed
datasetn = {'heart     '; 
            'iris      ';             
            };
names = cell2mat(datasetn);
verb = 0;%verbose mode

fprintf('Calculating Information Theoretic Measures!\n');
for itr=1:size(names,1)
    tnamet = strtrim(names(itr,:));%the dataset name 
    tname = sprintf('Data/%s',tnamet)
    %make sure a directory 'DataStats' exist
    fid = fopen(strcat('DataStats/',tnamet,'_inf_measures.txt'),'w');
    feval('information_measures',tnamet,fid,verb);
    fclose(fid);
    fprintf('%s\n', tnamet);
end
fprintf('Finished!\n');
fprintf('See the DataStats folder\n');