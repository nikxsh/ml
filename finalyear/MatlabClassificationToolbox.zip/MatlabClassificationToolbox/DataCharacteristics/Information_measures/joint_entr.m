%Calculates the joint entropy given the marginal probabilities of the
%attributes and the class

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%classes = 2;
classes = no_classes;
variables = size(datain, 2);

mindatain = min(datain);
maxdatain = max(datain);
ranges = maxdatain - mindatain;
%make 10 dicrete values for each continous variable
%step size
steps = ranges/nosteps;

%make all values discrete, 10 discrete values for each variable
for i=1:size(datain,1)    
    for j=1:size(datain,2)
        for count=1:nosteps
            diffs(count) = datain(i,j) - mindatain(j) - (count-1)*(steps(j));
        end
        diffs = abs(diffs);
        [minv, winner] = min(diffs);
        %newval = mindatain(j) + (winner-1)*steps(j);
        newval = mindatain(j) + (winner-1)*steps(j);
        if(i == size(datain,1))
            newval = mindatain(j) + (winner-1)*steps(j);
        end
        discrdatain(i,j) = newval;
    end
end

%make a matrix that contains all possible values for each variable
for i=1:size(datain,1)    
    for j=1:size(datain,2)
        indexval(i,j) = mindatain(j) + (i-1)*(steps(j)); 
    end
end

%initialise observation matrix
countobs = zeros(attrn, nosteps, classes);

for cno=1:classes
    %obsevations in the database
    for i=1:size(datain,1) 
        %variables
        if (dataout(i) == cno -1)
        for j=1:size(datain,2)
            %discrete steps for each variable
            for k=1:nosteps
                if  discrdatain(i,j) == indexval(k, j)
                    countobs(j,k,cno) = countobs(j,k,cno) + 1;
                end%if
            end%for
        end%for
        end%if
    end%for
        
        
end%classes

jointprob = countobs ./ size(datain,1);

%There is a joint prob between every variable and the class
%thus calulate the joint prob between the two possible class values and the
%nosteps possible discrete values for each variable

entropyval = zeros(1, 14);

%calculate the joint entropyb between each variable and the class
for i=1:size(datain,2)
    tempj(:,:) = jointprob(i,:,:);
    %send joint prob p(ij) through to entropy function
    jentropyval(i) = sum(entropy(tempj));
end

if verb == 1
fprintf(fid,'Joint entropy values, H(C,X), of class and attributes:\n');
for itr=1:attrn
    fprintf(fid,'%g     %g\n',itr, jentropyval(itr));
end
%jentropyval
fprintf(fid,'\n');

save('joint_entropy.txt','-ascii','jentropyval');
end%if
