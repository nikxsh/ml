%Calculate the mutual information between each variable and the class
%variable

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%Mutual information is the shared entropy between
%variables
%M(C,X) = H(C) + H(X) - H(C,X)
%Small values of M(C,X) implies that the variable will
%not by itself be a useful predictor of the class
for i=1:attrn%size(datain,2)-1
    mutualinf(i) = classent + attrentropy(i) - jentropyval(i);
end

if verb ==1
fprintf(fid,'The mutual information, M(C,X):\n'); 
for itr=1:attrn
    fprintf(fid,'%g     %g\n',itr, mutualinf(itr));
end
fprintf(fid,'\n');
%mutualinf

save('mutual_information.txt','-ascii','mutualinf');
end%if

%Determine if each variables mutual information
%contributes significantly
%M(C, X) > (d-1)(q-1) / N
%for a variable to contribute significantly to
%the class an observation belongs to
for i=1:attrn%size(datain,2)-1
    if mutualinf(i) > (((nosteps-1)*(no_classes-1))/size(datain, 1)) 
        varcontr(i) = 1;
    else varcontr(i) = 0;
    end%if
end%for

if verb ==1
fprintf(fid,'Variables that contribute:\n');
fprintf(fid,'M(C, X) > (d-1)(q-1) / N\n');
for itr=1:attrn
    fprintf(fid,'%g     %g\n',itr, varcontr(itr));
end
fprintf(fid,'\n');
end

%Calculate the average mutual information of the dataset
%avg M(C, X)
%novar = size(datain,2)-1;
avg_mi = sum(mutualinf)/attrn;%novar;

if verb ==1
fprintf(fid,'The average mutual information, sum(M(C,X))/d, of the dataset:\n');
fprintf(fid,'%g\n',avg_mi);
fprintf(fid,'\n');
%avg_mi
save('avg_dataset_mi.txt','-ascii','avg_mi');
end
%maximum information M(C,X) is given when H(C/X) or H(X/C) is zero
%if H(C/X) is zero, then class C is completely 
%predictable from attribute X

% 0 <= M(C,X) <= min(H(C), H(X))

%M(C,X) = H(C) - H(C/X)
%thus H(C/X) = H(C) - M(C,X)
%the lower the value the better the attribute describes the class 
for i=1:attrn%novar
    entr_cx(i) = classent - mutualinf(i);
end

if verb ==1
fprintf(fid,'The entropy H(C/X):\n');
for itr=1:attrn
    fprintf(fid,'%g     %g\n',itr,entr_cx(itr));
end
%entr_cx
fprintf(fid,'\n');
end%if

%M(C,X) = H(X) - H(X/C)
%thus H(X/C) = H(X) - M(C,X)
for i=1:attrn%novar
    entr_xc(i) = attrentropy(i) - mutualinf(i);
end

if verb ==1
fprintf(fid,'The entropy H(X/C):\n');
for itr=1:attrn
    fprintf(fid,'%g     %g\n',itr,entr_xc(itr));
end
%entr_xc
fprintf(fid,'\n');
end%if

%Calculate the avg no of attributes required
%see p.118 of Statlog project
avg_attr = classent / avg_mi;

if verb ==1
fprintf(fid,'The equivalent no of attributes:\n');
fprintf(fid,'H(C)/M(C,X)\n');
fprintf(fid,'%g\n',avg_attr);
fprintf(fid,'\n');
save('equiv_no_attr.txt','-ascii','avg_attr');
end

%Useful information about the class = avg M(C,X)
%non-useful information about the class = avg H(X) - avg M(C,X)  
%see p.119 of Statlog project

%Large values imply a dataset with lots of 
%irrelivant information (noise)
NS_ratio = (dsentropy - avg_mi)/ avg_mi;

if verb ==1
fprintf(fid,'The Noise to Signal ratio of the dataset:\n');
fprintf(fid,'(H(X)-M(C,X))/M(C,X)\n');
fprintf(fid,'%g\n',NS_ratio);
fprintf(fid,'%g\n');
save('NS_ratio.txt','-ascii','NS_ratio');
end%if

