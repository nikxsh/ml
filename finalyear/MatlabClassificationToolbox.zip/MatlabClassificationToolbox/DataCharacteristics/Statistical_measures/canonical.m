%Calculates the canonical correlation 

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%take a dataset and sort data according to class
splits = zeros(obs,p,q);
for i = 1:q
    %no of attributes
    for j=1:p+1
        %no of observations
        sk = 1;
        for k=1:obs
            
            if data1(k,p+1) == i-1
                splits(sk,j,i) = data1(k,j);
                sk = sk + 1;
            end
        end
    end
end

X = zeros(obs,p+1);
for k=1:q
    %extract the observations belonging to class k
    if k == 1
        temp = splits(1:ni(k),:,k); 
        X(1:ni(1),:) = temp; 
    else
        tot = 0;
        for iter=1:k-1
            tot = tot + ni(iter);
        end
        temp = splits(1:ni(k),:,k); 
        X(tot+1:tot+ni(k),:) = temp;  
    end 
end%for

%place the last column(class) in the first column and shift up
%the other columns
X2(:,1) = X(:,p+1);
X2(:,2:p+1) = X(:,1:p);
X = X2;

%Classes must start at 1,...
if min(X(:,1))== 0
    X(:,1) = X(:,1) + 1;
end

%calculate the Fisher discriminants
RAFisher2cda(X,1,2,0.05,fid, verb);
