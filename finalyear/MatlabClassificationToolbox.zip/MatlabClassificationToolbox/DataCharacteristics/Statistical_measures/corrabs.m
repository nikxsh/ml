%Calculates the absolute correlation for each class

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

abscorr = zeros(1,q);
%calculate pxy for every class
for k=1:q
    if k == 1 temp = X(1:ni(k),2:p+1);end
    if k > 1 temp = X(ni(k-1)+1:ni(k-1)+ni(k),2:p+1);end
    %calculate the covariance
    %Covariance of matrix - measure of strength
    %of linear relationships between variables.

    %the first column contains the class
    for i = 1:p%p-1
        for j=1:p
            coef = abs(corrcoef(temp(:,i),temp(:,j)));
            [r,c] = size(coef);
            if (r == 2 & c == 2)
                pxy(i,j) = coef(1,2);
            else pxy = coef;
            end%if
        end
    end
    
    %calculate the absolute correlation for each class
    %don't sum the diagonal components 
    abscorr(k) =  (sum(sum(pxy)) - (p))/((p)^2-(p));
end

%abscorr
fprintf(fid,'Mean absolute correlation coefficient, corr.abs : \n');
fprintf(fid,'(Measures interdependance between attributes)\n');
fprintf(fid,'The correlations between all pairs of attributes\n');
fprintf(fid,'are calculated for each class seperately.\n');
fprintf(fid,'The absolute values of these correlations are\n');
fprintf(fid,'averaged over all pairs of attributes and over\n');
fprintf(fid,'all classes giving the measure, corr.abs\n');
fprintf(fid,'corr.abs :\n');
fprintf(fid,'%g\n',abscorr);

if verb == 1
save('absolute_correlation.txt','-ascii','abscorr');
end