%Calculates test statistics for homogeniety of covariances
%Measures the lack of homogeneity of covariances
%Calculates the SD ratio

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%no of attributes
p = size(data1, 2)-1;
%fprintf('No of attributes: %g', p);
%no of observation
obs = size(data1, 1);
%fprintf('No of observations: %g',obs);
%no of classes
if min(data1(:,p+1)) == 0
    q = max(data1(:,p+1))+1;    
%make the smallest class value 0 if required
else 
    q = max(data1(:,p+1));
    data1(:,p+1) = data1(:,p+1)-1;
end
%fprintf('No of classes: %g',q);

temp = data1(:,p+1);
%Determine the number of observations in each class
%the class must start with 0,...,q-1
for i=1:q
    ni(i) = size(find(temp == i-1),1);
end
ni2 = sum(ni);

%fprintf('Total observations: %g', ni2); 

%take a dataset and sort data according to class
splits = zeros(obs,p,q);
for i = 1:q
    %no of attributes
    for j=1:p+1
        %no of observations
        sk = 1;
        for k=1:obs
            
            if data1(k,p+1) == i-1
                splits(sk,j,i) = data1(k,j);
                sk = sk + 1;
            end
        end
    end
end

X = zeros(obs,p+1);
for k=1:q
    %extract the observations belonging to class k
    if k == 1
        temp = splits(1:ni(k),:,k); 
        X(1:ni(1),:) = temp; 
    else
        tot = 0;
        for iter=1:k-1
            tot = tot + ni(iter);
        end
        temp = splits(1:ni(k),:,k); 
        X(tot+1:tot+ni(k),:) = temp;  
    end 
end%for


%place the last column(class) in the first column and shift up
%the other columns
X2(:,1) = X(:,p+1);
X2(:,2:p+1) = X(:,1:p);
X = X2;

%Classes must start at 1,...
X(:,1) = X(:,1) + 1;

%Data is now in correct format for MBoxtest.m
[M, denom] = MBoxtest(X,0.05);

%If M is zero the individual covariances matrices are equal to 
%the pooled covariance matrix
%M
%work out the constant
a = (2*p^2+3*p-1)/(6*(p+1)*(q-1));
b = 0;
c=0;
for i=1:q
    c = c + (1/(ni(i)-1));
end
b = c - (1/(obs-q));

%gamma = 1-a*b
const  = 1-a*b;

SD_ratio = exp(const*M/denom);
geom_mean = exp(M/denom);
SD_ratio_inv = SD_ratio^-1;

fprintf(fid,'\n');
fprintf(fid,'Test statistic for homogeneity of covariances :\n');
fprintf(fid,'(Measures the lack of homogeneity of covariances)\n');
fprintf(fid,'a : %g\n',a);
fprintf(fid,'b : %g\n',b);
fprintf(fid,'gamma = 1 - a*b\n');
fprintf(fid,'gamma : %g\n',const);
fprintf(fid, 'SD ratio = gamma*geometric mean\n');
fprintf(fid,'SD_ratio : %g\n',SD_ratio);
fprintf(fid,'SD_ratio(inv) : %g\n',SD_ratio_inv);

fprintf(fid,'\n');

if verb == 1
save('SD_ratio.txt','-ascii','SD_ratio');
end