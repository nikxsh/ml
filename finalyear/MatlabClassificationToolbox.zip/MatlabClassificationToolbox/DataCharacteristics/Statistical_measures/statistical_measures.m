function statistical_measures(datn, fid, pathn, verb)
%Calculates the statistical measures of a data set
%See the Statlog Project, Michie, 1994 for more information

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

datasetn = cast(datn,'char');
fprintf(fid,'Statistical measures for: %s dataset\n\n',datasetn);
%pathn = sprintf('Datasets\\%s\\%s.mat',datasetn,datasetn);
%.txt file
%data = load(strcat(datn,'.txt'));
%.arff file
[hdr data] = hdrload(datn);
data1 = data;
homogen
corrabs
canonical
