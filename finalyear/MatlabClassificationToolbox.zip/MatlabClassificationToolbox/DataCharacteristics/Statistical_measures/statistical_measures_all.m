function statistical_measures_all(verb)
%Calculates the statistical measures of a data set
%See the Statlog Project, Michie, 1994 for more information

%Usage: 
%statistical_measures_all(0) % verbose of
%statistical_measures_all(1) % verbose on

%verb - verbose mode, if verb == 1 then write all the stats
%to seperate txt files

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

clc
thisdir = pwd;
dpathn = 'D:\MATLAB7\work\Experiments\Measures\Data';
spathn = 'D:\MATLAB7\work\Experiments\Measures\DataStats\';

%Include all the data set names to be analysed
%datasetn = {'heart     '; 
%            'iris      ';             
%            };

cd(dpathn);
datasett = ls;
names = datasett(3:end,:);

%cd(spathn);

%names = cell2mat(datasetn);

fprintf('Calculating Statistical Measures!\n');
for itr=1:size(names,1)
    tname = strtrim(names(itr,:));%the dataset name 
    %make sure a directory 'DataStats' exist
    if tname(end)== 'f'%only considre .arff files
        fprintf('%s\n',tname);
        fid = fopen(strcat(spathn,tname,'_stat_measures.txt'),'w');
        feval('statistical_measures', tname,fid,spathn,verb);
        fclose(fid);
        fprintf('%s\n', tname);
    end
end

cd(thisdir);
fprintf('Finished!\n');
fprintf('See the DataStats folder\n');