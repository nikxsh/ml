function mutualinf = feature_selection(datasetn, mpath, verb)
%Returns the Mutual Information between each variable and the class
%Uses Information Theoretic Measures 
%See the Statlog Project, Michie, 1994 for more information

%Synopsis:
%feature_selection('C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data\iris.txt','C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data',0) % verbose off
%feature_selection('C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data\iris.txt','C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data',1) % verbose on

%Parameters
%datasetn - path and name of the data set
%mpath - path to where the text file with measures are saved
%verb - verbose mode, if verb == 1 then write all the stats
%to seperate txt files

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

dsn = cast(datasetn,'char');
%dsn = sprintf('%s/%s',dspath,datasetn);
%Writes out measures to a text file
fname = sprintf('%s/%s_inf_measures.txt',mpath,dsn);
fid = fopen(fname,'w');

%Load the data
data = load(dsn);
discl = 10;%number of discrete levels

%Basic Measures
obsn = size(data, 1); %number of rows
attrn = size(data, 2)-1;%determine the number of attributes (the last column is the class)
no_classes = max(data(:,attrn+1))+1;
datain = data(:,1:attrn);
dataout = data(:,attrn+1);

fprintf(fid,'N (number of observations): %g\n',obsn);
fprintf(fid,'p (number of attributes)  : %g\n',attrn);
fprintf(fid,'k (number of classes)     : %g\n',no_classes);  
fprintf(fid,'d (discrete levels)       : %g\n\n',discl);

%Perform Information Measures
%Calculates the entropy of the dataset (all the attributes)
attr_entr;
%Calculates the entropy of the class
class_entr;
%Calculates the joint entropy of the class and attribute
joint_entr;

%Calculates all the information measures, using the 
%mutual information between the class variable
%and the dataset variables
mutual;

fclose(fid);
