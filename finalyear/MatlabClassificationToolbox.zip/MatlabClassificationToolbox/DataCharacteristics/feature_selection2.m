function mutualinf = feature_selection2(data)
%Returns the Mutual Information between each variable and the class
%Uses Information Theoretic Measures 
%See the Statlog Project, Michie, 1994 for more information

%Synopsis:
%feature_selection('C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data\iris.txt','C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data',0) % verbose off
%feature_selection('C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data\iris.txt','C:\Documents and Settings\CvdWalt\Desktop\MatlabToolbox\Data',1) % verbose on

%Parameters
%datasetn - path and name of the data set
%mpath - path to where the text file with measures are saved
%verb - verbose mode, if verb == 1 then write all the stats
%to seperate txt files

%Written by C.M. van der Walt
%Meraka Institute, CSIR
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

discl = 10;%number of discrete levels
verb = 0;

%Basic Measures
obsn = size(data, 1); %number of rows
attrn = size(data, 2)-1;%determine the number of attributes (the last column is the class)
no_classes = max(data(:,attrn+1))+1;
datain = data(:,1:attrn);
dataout = data(:,attrn+1);

%Perform Information Measures
%Calculates the entropy of the dataset (all the attributes)
attr_entr;
%Calculates the entropy of the class
class_entr;
%Calculates the joint entropy of the class and attribute
joint_entr;

%Calculates all the information measures, using the 
%mutual information between the class variable
%and the dataset variables
mutual;