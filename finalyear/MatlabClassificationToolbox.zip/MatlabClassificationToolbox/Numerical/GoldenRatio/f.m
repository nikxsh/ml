function fx = f(x)
%Written by Christiaan M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

fx = x^2 - sin(x);
fprintf('f(%g) = %g\n',x,fx);