function [S, E, G] = goldensearch(a,b,delta,epsilon)
%Implementation of the golden ratio minimization algorithm
%Minimizes a function f with a single variable

%Written by Christiaan M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

%S returns the value of a local minima as well as the function value at
%that point
%[a, b] is the range of the values searched 
%delta is the tolerance for x values
%epsilon is the tollerance for y values (function values)

r1= (sqrt(5) - 1)/2;
r2= r1^2;
h = b-a;
ya = f(a); 
yb = f(b); 
c = a+r2*h;
d = a+r1*h;
yc = f(c);
yd = f(d);
k=1;
A(k)= a;
B(k) = b;
C(k) = c;
D(k) = d;

while(abs(yb-ya)>epsilon)|(h>delta)
k = k+1;
if(yc<yd)
	b = d;
	yb = yd;
	d = c;
	yd = yc;
	h = b - a;
	c = a + r2*h;
	yc = f(c);
else
	a = c;
	ya = yc;
	c = d;
	yc = yd;
	h = b - a;
	d = a+ r1*h;
	yd = f(d);
end

A(k) = a;
B(k) = b;
C(k) = c;
D(k) = d;

end%while 

dp = abs(b - a);
dy = abs(yb - ya);
p = a;
yp = ya;

if(yb < ya)
	p = b;
	yp = yb;
end

G = [A' C' D' B'];
S = [p yp];
E = [dp dy];