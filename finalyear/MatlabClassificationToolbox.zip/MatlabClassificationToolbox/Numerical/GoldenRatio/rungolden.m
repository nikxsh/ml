%Implementation of the golden ratio minimization algorithm
%Minimizes a function f with a single variable

%Written by Christiaan M. van der Walt
%Meraka Institute, CSIR
%Available from http://www.patternrecognition.co.za

clear
clc

%The range in which the optimal value is searched for is [begins, ends]
begins = -1;
ends = 1;
delta = 0.01;%tolerance of the values (required for stopping criteria)
epsilon = 0.01;%tolerance of the function values (required for stopping criteria)

[S, E, G] = goldensearch(begins, ends, delta, epsilon);

fprintf('\nOptimal value = %g\n',S(1));
fprintf('f(%g) = %g\n',S(1), S(2));
