function barplotres(ws, titlestr, xl, yl, cl,fdir)
%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

load(ws);

if strcmp(cl,'k')
    errs = knnerrs;
elseif strcmp(cl,'opt')
    errs = opterrs;
elseif strcmp(cl,'GMM')
    errs = gmmerrs;
end

%Plot the classification results
%clrs = ['r' 'g' 'b' 'k' 'c' 'm' 'y' 'w'];
clrs = ['r'];

fh1 = figure;
bar(errs,clrs(1));
xlabel(xl);
ylabel(yl);
hold on;
for itr=2:length(errs)
    bar(itr,errs(itr),clrs(1));   
end
%legend(clnames2{1:stp},'Location','NorthEastOutside');
title(sprintf('%s',titlestr));
savestr = sprintf('%s/%s_1.bmp',fdir,titlestr);
saveas(fh1,savestr,'bmp');
savestr = sprintf('%s/%s_1.fig',fdir,titlestr);
saveas(fh1,savestr,'fig');

