%MATLAB CLASSIFICATION TOOLBOX

%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%Licence
%This code is published under the GNU Public licence

%Make sure you run this script from the toolbox home directory

clear all;
clc;
close all;
%warning off all;

%Add package folders to the Matlab path
thisdir = pwd;
addpath(genpath(thisdir));%add folders recursively

dsfolder = '/DataSets';%path to the data set folder
mfolder = '/DataMeasures';%write measures results to this folder
%dsnames = {'artificial2.txt','artificial1.txt'};%{'iris.txt','artificial2.txt','artificial1.txt','ionosphere.txt','splice.txt'};
dsnames  = {'iris.txt'};
fdir = sprintf('%s/Figures',thisdir);
fsel = 0;%whether or not to perform feature selection

%Classifier Meta Parameters
%kNN
kMax = 5;
kMin = 1;
kinc= 1;
%opt NN
hMin = 1;
hMax = 5;
hninc = 1;

%GMM
minM = 3;%min no. of mixtures
minc = 1;
maxM = 3;%max no. of mixtures
gmmverb = 0;%verbose for EM algorithm convergence

%DT
dtm = 2;%1-entropy, 2-mutual information

%Select Classifiers
%Parametric
ldc = 1;
lgc = 0;%only for two-class problems
gc = 1;
nbc = 1;
tdc = 1;%t-distribution classifier
tdcn= 1;%t-distribution clas. naive
tdcsn=1;%t-distribution clas. semi-naive
%Semi-parametric
gmmc = 1;
%Non-parametric
knnc = 1; 
optc = 0;
dtc = 1;

for dsitr=1:length(dsnames)
       
    dsname = sprintf('%s/%s',dsfolder,dsnames{dsitr});
    fprintf('%s\n',dsname);
    clitr = 1;
    clnames = {};
    fprintf('%s\n',dsname);
    data = load(dsname);   
           
    %Classify Data
    %Linear Classifier (Gaussian)
    if lgc == 1
        fprintf('Normal-Based Linear Classifier\n');
        lgerr = lgclassifierfC(dsname); 
        fprintf('lgerr %g\n',lgerr);
        clres(clitr) = lgerr;
        clnames = [clnames {'Linear (Gaussian)'}];
        clitr = clitr+1;
    end
    
    %Linear Classifier (Fishers) 
    if ldc == 1
        fprintf('Linear Classifier (Fishers)\n');
        lderr = ldclassifierfC(dsname); 
        fprintf('lderr %g\n',lderr);
        clres(clitr) = lderr;
        clnames = [clnames {'Linear (Fishers)'}];
        clitr = clitr+1;
    end
    
    %Naive Bayes (Gaussian)
    if nbc == 1
        fprintf('NB Classifier\n');
        nberr = nbclassifierf(dsname);
        fprintf('nberr %g\n',nberr);
        clres(clitr) = nberr;
        clnames = [clnames {'NB'}];
        clitr = clitr+1;
    end
    
    %Gaussian Classifier (ML)
    if gc == 1
        fprintf('Gaussian Classifier\n');
        gausserr = gaussianclassifierf(dsname);
        fprintf('gausserr %g\n',gausserr);
        clres(clitr) = gausserr;
        clnames = [clnames {'Gaussian (ML)'}];
        clitr = clitr+1;
    end
    
    %t-distribution classifier (full covariance)
    if tdc == 1
        [tderr tderrs] = tdistclassifier(dsnames{dsitr});; 
        fprintf('t-dist(full)   err = %g\n',tderr);
        clres(clitr) = tderr;
        clnames = [clnames {'t-distribution (full)'}];
        clitr = clitr+1;
    end
    
    %t-distribution classifier (diagonal  covariance, rotate data)
    if tdcsn == 1
        [tdsnerr tdsnerrs] = tdistclassifier_snaive(dsnames{dsitr});; 
        fprintf('t-dist(semi-naive) err = %g\n',tdsnerr);
        clres(clitr) = tdsnerr;
        clnames = [clnames {'t-distribution (semi-naive)'}];
        clitr = clitr+1;
    end
    
    %t-distribution classifier (diagonal covariance)
    if tdcn == 1
        [tdnerr tdnerrs] = tdistclassifier_naive(dsnames{dsitr});; 
        fprintf('t-dist(naive)  err = %g\n',tdnerr);
        clres(clitr) = tdnerr;
        clnames = [clnames {'t-distribution (diagonal)'}];
        clitr = clitr+1;
    end
    
    %k-Nearest-Neighbour Classifier
    if knnc == 1
        fprintf('kNN Classifier\n');
        [knnerr optK knnerrs] = knnclassifierf(dsname,kMin,kinc,kMax);
        fprintf('knnerr %g\n',knnerr);
        clres(clitr) = knnerr;
        clnm = sprintf('kNN (k = %g)',optK);
        clnames = [clnames {clnm}];
        clitr = clitr+1;
    end
    
    %Opt Neural Network
    if optc == 1
        thisdir = pwd;
        cd('Classifiers/opt');
        fprintf('NN (opt) Classifier\n');
        [opterr opthn opterrs] = optclassifier(dsname, hMin, hninc, hMax);
        cd(thisdir); 
        fprintf('opterr %g\n',opterr);
        clres(clitr) = opterr;
        clnm = sprintf('NN (Opt)(HidN = %g)',opthn);
        clnames = [clnames {clnm}];
        clitr = clitr+1;
    end
   
    %Decision Tree
    if dtc == 1
        fprintf('DT Classifier\n');
        dterr = DTclassifierf(dsname, dtm);
        fprintf('dterr %g\n',dterr);
        clres(clitr) = dterr;
        clnames = [clnames {'DT'}];
        clitr = clitr+1;
    end
    
    %Gaussian Mixture Model
    if gmmc == 1
        fprintf('GMM (full) Classifier\n');
        [gmmerr optM gmmerrs] = GMMclassifierf(dsname, minM, minc, maxM, gmmverb);
        fprintf('gmmerr %g\n',gmmerr);
        clres(clitr) = gmmerr;
        clnm = sprintf('GMM (Mix = %g)',optM);
        clnames = [clnames {clnm}];
        clitr = clitr+1;
    end
        
    %Save the results
    try%if in the myToolbox directory
        thisdir = pwd;
        wsn = sprintf('%s/%s.mat',dsfolder,dsnames{dsitr});
        save(wsn);
    catch
        wsn = sprintf('%s.mat',dsnames{dsitr});
        save(wsn);
    end
    
    %Plot the classification results
    plotmyres(wsn, dsnames{dsitr},fdir);
           
    %Plot bar plot of
    %Error rates for kNN k values
    if knnc == 1
        ktstr = sprintf('kNN Classification Errors (%s)',dsnames{dsitr});
        kxl = sprintf('k Values');
        kyl = sprintf('Classification Error');
        barplotres(wsn, ktstr, kxl, kyl, 'k',fdir);
    end     
    
    %Error rates for different no of mixtures
    if gmmc == 1
        mtstr = sprintf('GMM Classification Errors (%s)',dsnames{dsitr});
        mxl = sprintf('Mixtures');
        myl = sprintf('Classification Error');
        barplotres(wsn, mtstr, mxl, myl, 'GMM');
    end    
   
end%for dsitr



