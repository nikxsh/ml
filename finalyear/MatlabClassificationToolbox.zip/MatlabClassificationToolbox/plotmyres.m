function plotmyres(ws, titlestr,fdir)
%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

load(ws);

%Plot the classification results
clrs = ['r' 'g' 'b' 'k' 'c' 'm' 'y' 'w'];
nocl = length(clnames);%number of classifiers
if nocl > 6
    stp = 6;
else
    stp = nocl;
end

%Re-arrange the results in sequence of performance
%[merr midx] = min(clres);
[aserr asidx] = sort(clres,'ascend');
clres2 = clres(asidx);
clnames2 = clnames(asidx);

for itr=1:length(clnames2)
    str = sprintf('%s (%g)',clnames2{itr},clres2(itr));
    clnames2{itr} = str;
end

%Plot 6 best classifiers
fh1 = figure;
bar(clres2(1:stp),clrs(1));
hold on;
for clitr=2:stp%length(clres)
    bar(clitr,clres2(clitr),clrs(clitr));   
end
legend(clnames2{1:stp},'Location','NorthEastOutside');
title(sprintf('%s',titlestr));
%savestr = sprintf('%s/%s_1.bmp',fdir,titlestr);
%saveas(fh1,savestr,'bmp');
%savestr = sprintf('%s/%s_1.fig',fdir,titlestr);
%saveas(fh1,savestr,'fig');

%Plot rest of classifiers
if nocl > 6
    fh2 = figure;
    bar(clres2(7:nocl),clrs(1));
    hold on;
    for clitr=8:nocl%length(clres)
        bar(clitr-6,clres2(clitr),clrs(clitr-6));    
    end
    legend(clnames2{stp+1:nocl},'Location','NorthEastOutside');
    title(sprintf('%s',titlestr));
    %savestr = sprintf('%s/%s_2.bmp',fdir,titlestr);
    %saveas(fh2,savestr,'bmp');
    %savestr = sprintf('%s/%s_1.fig',fdir,titlestr);
    %saveas(fh2,savestr,'fig');
end