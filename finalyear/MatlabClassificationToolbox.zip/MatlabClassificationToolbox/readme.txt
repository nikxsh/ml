%MATLAB CLASSIFICATION TOOLBOX

%Written by C.M van der Walt
%CSIR, Meraka Institute
%More resources available at http://www.patternrecognition.co.za

%Reference:
%C.M. van der Walt and E. Barnard,�Data characteristics that determine classifier perfromance�, in Proceedings
%of the Sixteenth Annual Symposium of the Pattern Recognition Association of South Africa,  pp.160-165, 2006. 
%Available [Online] http://www.patternrecognition.co.za

%Licence
%This code is published under the GNU Public licence

Instructions:
Run the example.m file from the directory in which you want to install the toolbox
The example script classifies the iris data sets with all the classifiers
If the installation is correct, the example script will give a bar plot of the 
classification results for the iris data set
